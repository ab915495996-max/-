# Dynamic Risk Budgeting Backtester

A Python-based quantitative research framework for multi-asset allocation,
dynamic risk budgeting and macro regime based portfolio construction.

## Overview

This project implements:

- Multi-asset return processing
- Portfolio backtesting framework
- Equal weight allocation
- Inverse volatility allocation
- Risk parity / risk budgeting optimization
- Bridgewater-style growth-inflation regime allocation
- Dynamic IR/Sharpe based risk budget adjustment
- Performance evaluation:
  - Annualized return
  - Volatility
  - Sharpe ratio
  - Maximum drawdown
  - Calmar ratio
- Interactive visualization GUI

## Research Framework

```
Market Data
    |
    v
Data Cleaning & Return Calculation
    |
    v
Growth / Inflation Regime Classification
    |
    v
Asset Pool Construction
    |
    v
Risk Budget Optimization
    |
    v
Dynamic Allocation Backtest
    |
    v
Performance Analysis
```

## Methodology

### Risk Budget Optimization

The portfolio weight optimization solves:

min:

0.5 * w.T Sigma w - lambda * sum(b_i log(w_i))

where:

- w: portfolio weights
- Sigma: covariance matrix
- b: target risk budget

Optimization methods:

- L-BFGS-B
- SLSQP fallback

## Dynamic Risk Budget

The framework supports:

- Rolling return estimation
- Rolling volatility estimation
- IR / Sharpe signal construction
- Softplus transformation
- Dynamic risk contribution adjustment

## Data

The project uses:

- Asset price data
- PMI expectation/actual data
- CPI expectation/actual data
- PPI expectation/actual data
- CPI/PPI proxy regression results

Original market data may require proper data licensing.

## Installation

```bash
pip install -r requirements.txt
```

## Run

```bash
python src/dynamic_risk_budgeting_backtester.py
```

## Project Structure

```
.
├── src
│   └── dynamic_risk_budgeting_backtester.py
│
├── data
│   ├── asset data
│   ├── PMI data
│   ├── CPI data
│   ├── PPI data
│   └── regression results
│
├── results
│
├── requirements.txt
└── README.md
```

## Future Improvements

- Modularize the current research script
- Add unit tests
- Add transaction cost model based on turnover
- Add walk-forward validation
- Separate data layer and strategy layer
