# -*- coding: utf-8 -*-
"""
动态交互式回测GUI (tkinter) —— 分页显示，每页4图
含: 自定义风险预算 + 每子图独立缩放 + 重名自定义
    + 桥水全天候(增长×通胀交叉四环境，手动/自动) + 曲线重命名 + 日度收益率 + 分页翻页
    + 整体指标页(年化收益/年化波动/夏普/卡玛/最大回 撤)
"""

import numpy as np
import pandas as pd
from scipy.optimize import minimize
import matplotlib
matplotlib.use('TkAgg')
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
import statsmodels.api as sm
from scipy import stats
import os, warnings
import math
from itertools import combinations
warnings.filterwarnings('ignore')

for fp in ['C:/Windows/Fonts/msyh.ttf','C:/Windows/Fonts/simhei.ttf']:
    if os.path.exists(fp):
        try: fm.fontManager.addfont(fp)
        except Exception: pass
plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','Arial Unicode MS','DejaVu Sans']
plt.rcParams['font.family']='sans-serif'; plt.rcParams['axes.unicode_minus']=False

def excel_serial_to_datetime(s):
    s=pd.Series(s)
    if pd.api.types.is_datetime64_any_dtype(s): return pd.to_datetime(s)
    if pd.api.types.is_numeric_dtype(s):
        if s.between(20000,60000).mean()>0.8: return pd.to_datetime(s,unit='D',origin='1899-12-30')
        return s
    for fmt in ('%Y%m%d','%Y-%m-%d','%Y/%m/%d','%Y.%m.%d'):
        try: return pd.to_datetime(s,format=fmt)
        except Exception: pass
    return pd.to_datetime(s,errors='coerce')

def load_prices(path):
    df=pd.read_excel(path)
    date_col=None
    for c in df.columns:
        if str(c).strip() in ['日期','date','Date','时间','time','交易日期','交易日']:
            date_col=c; break
    if date_col is None:
        best,best_score=None,0
        for c in df.columns:
            sc=pd.to_datetime(excel_serial_to_datetime(df[c]),errors='coerce').notna().mean()
            if sc>best_score: best,best_score=c,sc
        date_col=best
    dates=excel_serial_to_datetime(df[date_col].copy())
    df=df.assign(_d=dates).drop(columns=[date_col]).dropna(subset=['_d'])
    df['_d']=pd.to_datetime(df['_d'],errors='coerce')
    df=df.dropna(subset=['_d']).set_index('_d').sort_index()
    p=df.apply(pd.to_numeric,errors='coerce')
    p.columns=[f'{c}' for c in p.columns]
    return p

# ============ 整体(全区间)指标 ============
def annual_report(pr):
    """对某条策略的日度收益率序列 pr 计算整体指标, 返回 dict"""
    pr=pr.dropna()
    if len(pr)<2:
        return dict(年化收益率=np.nan, 年化波动率=np.nan, 夏普率=np.nan,
                    最大回撤=np.nan, 卡玛比率=np.nan)
    ret_daily=pr  # 已是日度收益率
    ann_ret=(1+ret_daily).prod()**(252/len(ret_daily))-1        # 年化收益率
    ann_vol=ret_daily.std(ddof=1)*np.sqrt(252)                  # 年化波动率
    sharpe=ann_ret/ann_vol if ann_vol>0 else np.nan        # 年化夏普率
    nav=(1+ret_daily).cumprod()                                 # 净值
    dd=nav/nav.cummax()-1                                       # 回撤序列
    max_dd=dd.min()                                             # 最大回撤(负值)
    calmar=ann_ret/abs(max_dd) if max_dd<0 else np.nan          # 卡玛比率
    return dict(年化收益率=ann_ret, 年化波动率=ann_vol, 年化夏普率=sharpe,
                最大回撤=max_dd, 卡玛比率=calmar)


def yearly_report(pr):
    """
    按年计算策略的年度指标。
    每年: 年化收益率、年化波动率、年化夏普率、最大回撤、卡玛比率
      年化收益率/年化波动率 用该年的交易日数折算
    返回 DataFrame: index=年份
    """
    pr = pr.dropna()
    if len(pr) < 2:
        return pd.DataFrame()
    years = sorted(set(pr.index.year))
    records = []
    # 每年初始净值 = 上一年末净值
    nav_all = (1 + pr).cumprod()
    year_start_nav = {}
    for y in years:
        sub = pr[pr.index.year == y]
        if len(sub) < 2:
            continue
        ndays = len(sub)                     # 该年交易日数
        # 起始净值: 上一年最后一个交易日的净值(若无则为1)
        prev = pr[pr.index.year < y]
        start_nav = (1 + prev).prod() if len(prev) > 0 else 1.0
        year_nav = (1 + sub).prod()          # 该年(1+r)连乘=该年净值倍数
        ann_ret = year_nav - 1               # 当年实际收益率 = 年末净值/上一年末净值 - 1
        ann_vol = sub.std(ddof=1) * np.sqrt(ndays)   # 年化波动(用该年交易日数)
        sharpe = ann_ret / ann_vol if ann_vol > 0 else np.nan
        nav_year = start_nav * (1 + sub).cumprod()   # 该年净值(从年初起算)
        dd = nav_year / nav_year.cummax() - 1
        max_dd = dd.min()
        calmar = ann_ret / abs(max_dd) if max_dd < 0 else np.nan
        records.append(dict(年份=y, 年化收益率=ann_ret, 年化波动率=ann_vol,
                            年化夏普率=sharpe, 最大回撤=max_dd, 卡玛比率=calmar,
                            交易日数=ndays))
    return pd.DataFrame(records).set_index('年份')







def leverage_returns(pr, L, rf=0.03):
    """对日收益序列 pr 加杠杆 L 倍(按无风险利率 rf 融资):
       杠杆后日收益 = L*pr - (L-1)*(rf/252);  L=1 时原样返回"""
    if L is None or L<=0: return pr
    if abs(L-1.0)<1e-9: return pr
    rfd=rf/252.0
    return L*pr - (L-1.0)*rfd


def cost_returns(pr, cost_rate=0.001):
    """
    对日收益序列 pr 模拟交易成本。
    假设每日调仓(或简化): 每日收益要扣除成本
    成本按 |日收益率| 或固定比例收取, 简化为: 扣成本后日收益 = (1+r)*(1-cost) - 1
    """
    if cost_rate is None or cost_rate <= 0: return pr
    # 简化模型: 每天换手, 扣除成本率(按双向/单向近似)
    return (1 + pr) * (1 - cost_rate) - 1


def risk_budget_weights(sigma, budgets, lam=1.0):
    n=sigma.shape[0]
    b=np.asarray(budgets,float); b=np.maximum(b,1e-8)/np.maximum(b,1e-8).sum()
    def obj(w): return 0.5*w@sigma@w - lam*np.sum(b*np.log(w))
    def jac(w): return sigma@w - lam*b/w
    w0=np.full(n,1.0/n)
    res=minimize(obj,w0,jac=jac,method='L-BFGS-B',bounds=[(1e-10,None)]*n,options={'maxiter':3000})
    if not res.success:
        res=minimize(obj,w0,jac=jac,method='SLSQP',bounds=[(1e-10,None)]*n,options={'maxiter':3000})
    w=np.clip(res.x,1e-10,None); return w/w.sum()


def calc_momentum_ir(rets, asset, idx, L_mu, L_sigma):
    """
    在调仓位置 idx 上，使用调仓日前的数据计算资产的预测 Sharpe / 动量 IR。

    L_mu:
        收益率估计窗口

    L_sigma:
        波动率估计窗口



    注意：
        iloc 右端不包含 idx，
        所以全部使用调仓日之前的数据。
    """

    L_mu = int(L_mu)
    L_sigma = int(L_sigma)

    if L_mu <= 1 or L_sigma <= 1:
        return np.nan

    # -----------------------------
    # 收益率窗口
    # -----------------------------
    mu_start = max(0, idx - L_mu)

    mu_win = (
        rets[asset]
        .iloc[mu_start:idx]
        .dropna()
    )

    # -----------------------------
    # 波动率窗口
    # -----------------------------
    sigma_start = max(0, idx - L_sigma)

    sigma_win = (
        rets[asset]
        .iloc[sigma_start:idx]
        .dropna()
    )

    # 历史数据不够
    if len(mu_win) < L_mu:
        return np.nan

    if len(sigma_win) < L_sigma:
        return np.nan

    # -----------------------------
    # 年化收益率预测
    # -----------------------------
    mu_ann = mu_win.mean() * 252.0

    # -----------------------------
    # 年化波动率预测
    # -----------------------------
    sigma_ann = sigma_win.std(ddof=1) * np.sqrt(252.0)

    if (
        np.isnan(sigma_ann)
        or sigma_ann <= 1e-12
    ):
        return np.nan

    # -----------------------------
    # 预测 Sharpe / 动量 IR
    # -----------------------------
    ir = (
        mu_ann
    ) / sigma_ann

    # 国君研报做法：限制在 [-3.5, 3.5]
    ir = np.clip(
        ir,
        -3.5,
        3.5
    )

    return float(ir)


def momentum_risk_budgets(
        rets,
        assets,
        idx,
        momentum_params,
        momentum_k,
):
    """
    根据每个资产自己的 L_mu / L_sigma 计算预测 IR，
    再转换为第一层的动态风险预算。

    返回：
        b      : 归一化后的风险预算
        ir_map : 每个资产当前预测 IR
    """

    scores = []
    ir_map = {}

    for asset in assets:

        pars = momentum_params[asset]

        L_mu = int(
            pars['L_mu']
        )

        L_sigma = int(
            pars['L_sigma']
        )

        ir = calc_momentum_ir(
            rets=rets,
            asset=asset,
            idx=idx,
            L_mu=L_mu,
            L_sigma=L_sigma
        )


        if np.isnan(ir):
            return None, None

        ir_map[asset] = ir

        # -----------------------------------------
        # b_i = [1 + ln(1 + exp(k * IR_i))]^2
        #
        # np.logaddexp(0, x)
        # 等价于 ln(1 + exp(x))
        # 并且数值上更稳定
        # -----------------------------------------
        softplus = np.logaddexp(
            0.0,
            momentum_k * ir
        )

        score = (
            1.0 + softplus
        ) ** 2

        scores.append(score)

    scores = np.asarray(
        scores,
        dtype=float
    )

    if (
        len(scores) == 0
        or scores.sum() <= 0
    ):
        return None, None

    # 风险预算归一化
    b = scores / scores.sum()

    return b, ir_map



def inverse_vol_weights(window):
    sd=window.std()*np.sqrt(252); inv=1.0/np.maximum(sd,1e-12); return inv/inv.sum()

def _rebal_period(freq, rets_index):
    if freq=='Q': return rets_index.to_period('Q')
    elif freq=='6M': return rets_index.to_period('2Q')
    elif freq=='Y': return rets_index.to_period('Y')
    else: return rets_index.to_period('M')

def _rebal_days(freq, rets):
    period = _rebal_period(freq, rets.index)
    # 每个周期首个交易日作为调仓日(与原有逻辑一致)
    return set(rets.index.to_series().groupby(period).first().values)

def _active_assets(win, assets, min_obs):
    """返回窗口 win 内, 有效收益数据 >= min_obs 的活跃资产列表"""
    if len(win) < min_obs:
        return []
    valid = win.notna().sum()                # 每列非空收益数
    return list(valid[valid >= min_obs].index)

def make_curve(prices, assets, method, budgets=None, lookback=126, freq='M',
               min_obs=None, start=None):
    """
    动态配权回测。
    - start: 回测起始日(None=用最早日期)。起始日前历史可用于算权重, 不计入净值。
    - min_obs: 资产须在窗口内攒满多少有效收益才纳入。None 时 = lookback(与配权窗口一致)。
    - 每个调仓日只对活跃资产(攒满 lookback 历史)算权重; 未纳入资产权重0、收益视作0。
    """
    if min_obs is None:
        min_obs = lookback                 # ★ 攒满 lookback 天才配权
    rets = prices[assets].pct_change().replace([np.inf,-np.inf],np.nan)
    n = len(assets)
    days = _rebal_days(freq, rets)
    loop_index = rets.index[rets.index >= start] if start is not None else rets.index

    w_cur=None; out=[]; w_hist={}
    for d in loop_index:
        if d in days:
            idx = rets.index.get_loc(d)
            win = rets.iloc[max(0, idx-lookback):idx]
            active = _active_assets(win, assets, min_obs)
            if active:
                w = np.zeros(n)
                sub = win[active]
                if len(sub) >= min_obs:
                    if method=='equal':
                        w_sub = np.ones(len(active))/len(active)
                    elif method=='invvol':
                        w_sub = inverse_vol_weights(sub)
                    elif method=='riskpar':
                        w_sub = risk_budget_weights(sub.cov().values,
                                                     np.ones(len(active))/len(active))
                    elif method=='rb':
                        b_full = np.asarray(budgets,float)
                        b_sub = np.array([b_full[assets.index(a)] for a in active])
                        b_sub = np.maximum(b_sub,1e-8)/np.maximum(b_sub,1e-8).sum()
                        w_sub = risk_budget_weights(sub.cov().values, b_sub)
                    w_sub = np.asarray(w_sub, dtype=float).ravel()
                    for k,a in enumerate(active):
                        w[assets.index(a)] = w_sub[k]
                    w_cur = w
                    w_hist[d] = w_cur.copy()
        r_row = rets.loc[d].fillna(0).values
        ret_d = w_cur @ r_row if w_cur is not None else np.nan
        out.append((d, ret_d))
    pr = pd.Series(dict(out)).sort_index()
    if start is not None:
        pr = pr[pr.index >= start]
    pr = pr.dropna()
    if w_hist:
        wdf = pd.DataFrame(list(w_hist.values()), index=list(w_hist.keys()),
                           columns=assets).sort_index()
    else:
        wdf = pd.DataFrame()
    return pr, wdf




# ============ 增长 × 通胀：互斥交叉四环境 ============
CROSS_MACRO_ENVS = (
    '增长超预期 × 通胀超预期',
    '增长超预期 × 通胀低于预期',
    '增长低于预期 × 通胀超预期',
    '增长低于预期 × 通胀低于预期',
)

CROSS_ENV_MAP = {
    ('up', 'up'): CROSS_MACRO_ENVS[0],
    ('up', 'down'): CROSS_MACRO_ENVS[1],
    ('down', 'up'): CROSS_MACRO_ENVS[2],
    ('down', 'down'): CROSS_MACRO_ENVS[3],
}


def validate_cross_env_assets(env_assets, require_nonempty=True):
    """
    校验增长 × 通胀交叉四环境。

    关键约束：
    1. 必须恰好是四个交叉环境；
    2. 同一资产最多只能属于一个环境；
    3. require_nonempty=True 时，四个环境都必须至少有一个资产。

    这样第二层的四个环境组合 Y1~Y4 不会因为同一真实资产
    同时出现在两个环境里而产生“重复持仓式”的结构重叠。
    """
    if not isinstance(env_assets, dict):
        raise ValueError('env_assets 必须是字典')

    missing_envs = [e for e in CROSS_MACRO_ENVS if e not in env_assets]
    extra_envs = [e for e in env_assets if e not in CROSS_MACRO_ENVS]

    if missing_envs or extra_envs:
        msg = []
        if missing_envs:
            msg.append('缺少环境：' + '；'.join(missing_envs))
        if extra_envs:
            msg.append('存在旧环境/未知环境：' + '；'.join(extra_envs))
        raise ValueError(
            '全天候现在使用“增长 × 通胀”交叉四环境。' + '；'.join(msg)
        )

    if require_nonempty:
        empty_envs = [e for e in CROSS_MACRO_ENVS if not env_assets.get(e)]
        if empty_envs:
            raise ValueError(
                '交叉后以下环境为空，无法做完整四环境风险平价：'
                + '；'.join(empty_envs)
            )

    owner = {}
    duplicates = []

    for env in CROSS_MACRO_ENVS:
        for asset in env_assets.get(env, []):
            if asset in owner:
                duplicates.append((asset, owner[asset], env))
            else:
                owner[asset] = env

    if duplicates:
        detail = '；'.join(
            f'{asset}: {env1} / {env2}'
            for asset, env1, env2 in duplicates
        )
        raise ValueError(
            '检测到同一资产被分到多个交叉环境。'
            '新模型要求每个资产只能属于一个环境。重复项：'
            + detail
        )

    return True


# ============ 全天候：全样本静态资产筛选（Effective Rank + MaxDet） ============
def _effective_rank_from_corr(corr_matrix, tol=1e-12):
    """
    根据相关矩阵的特征值谱计算 Effective Rank：

        p_j = lambda_j / sum(lambda)
        ER  = exp(-sum p_j log p_j)

    数值上将极小的负特征值截为0。
    """
    corr_matrix = np.asarray(corr_matrix, dtype=float)
    corr_matrix = 0.5 * (corr_matrix + corr_matrix.T)

    eigvals = np.linalg.eigvalsh(corr_matrix)
    eigvals = np.clip(eigvals, 0.0, None)

    total = eigvals.sum()
    if (not np.isfinite(total)) or total <= tol:
        return 1.0, eigvals

    p = eigvals[eigvals > tol] / total
    er = float(np.exp(-np.sum(p * np.log(p))))
    return er, eigvals


def _maxdet_subset_exact(corr_df, k, eps=1e-10):
    """
    在所有 |S|=k 的资产子集中，精确穷举求解：

        max log det(C[S,S] + eps I)

    其中 C 为相关矩阵。
    使用 slogdet 避免直接计算 determinant 的数值不稳定。

    返回：
        selected_assets
        best_logdet
        best_det_raw
        combination_count
    """
    assets = list(corr_df.columns)
    n = len(assets)

    if n == 0:
        raise ValueError('MaxDet候选资产为空')

    k = int(k)
    if k < 1 or k > n:
        raise ValueError(f'MaxDet的k必须满足 1 <= k <= {n}，当前 k={k}')

    corr = np.asarray(corr_df.values, dtype=float)
    corr = 0.5 * (corr + corr.T)
    np.fill_diagonal(corr, 1.0)

    combination_count = math.comb(n, k)

    # k == n 时没有选择问题，直接全选
    if k == n:
        idx = tuple(range(n))
        sub = corr[np.ix_(idx, idx)]
        sign, logdet = np.linalg.slogdet(sub + eps * np.eye(k))
        if sign <= 0:
            raise ValueError('相关矩阵数值异常，加入eps后仍无法得到正行列式')
        raw_det = float(max(np.linalg.det(sub), 0.0))
        return assets, float(logdet), raw_det, combination_count

    best_idx = None
    best_logdet = -np.inf
    tie_tol = 1e-12

    # 精确穷举：第一个达到最优值的组合保留，保证结果可重复
    for idx in combinations(range(n), k):
        sub = corr[np.ix_(idx, idx)]
        sign, logdet = np.linalg.slogdet(
            sub + eps * np.eye(k)
        )

        if sign <= 0 or not np.isfinite(logdet):
            continue

        if logdet > best_logdet + tie_tol:
            best_logdet = float(logdet)
            best_idx = idx

    if best_idx is None:
        raise ValueError('MaxDet优化失败：没有找到有效资产子集')

    selected_assets = [assets[i] for i in best_idx]
    best_sub = corr[np.ix_(best_idx, best_idx)]
    best_det_raw = float(max(np.linalg.det(best_sub), 0.0))

    return (
        selected_assets,
        best_logdet,
        best_det_raw,
        combination_count
    )


def select_static_env_assets_maxdet(
        prices,
        env_assets,
        start=None,
        eps=1e-10,
        min_common_obs=20,
):
    """
    对四个宏观环境分别进行一次性的静态资产筛选。

    流程（每个环境 q）：
        1. 使用整个回测区间的日收益率；
           - start=None：使用全部可用样本
           - start给定：使用 start 到数据末日
        2. 只使用该环境所有候选资产共同有效的日收益样本；
        3. 计算候选资产相关矩阵 C_q；
        4. 计算 Effective Rank:
               ER_q = exp(-sum p_j log p_j)
        5. 确定数量：
               K_q = ceil(ER_q)
        6. 在所有 C(N_q, K_q) 个子集中精确求解：
               max log det(C_q[S,S] + eps I)
        7. 得到固定资产集合 S_q*。

    该函数只调用一次；筛选结果在整个回测期间固定，
    后续 make_allweather_curve 只动态调整风险预算权重，不再换资产。

    返回：
        selected_env_assets : {env: [selected assets]}
        selection_info      : 每个环境的详细筛选信息
    """
    validate_cross_env_assets(
        env_assets,
        require_nonempty=True
    )

    selected_env_assets = {}
    selection_info = {}

    for env in CROSS_MACRO_ENVS:
        candidates = list(dict.fromkeys(env_assets[env]))
        n = len(candidates)

        if n == 0:
            raise ValueError(f'环境【{env}】没有候选资产')

        missing_cols = [
            a for a in candidates
            if a not in prices.columns
        ]
        if missing_cols:
            raise ValueError(
                f'环境【{env}】以下资产不在价格数据中：'
                + '、'.join(missing_cols)
            )

        p = prices[candidates].copy()
        if start is not None:
            p = p.loc[p.index >= pd.Timestamp(start)]

        if len(p) < 2:
            raise ValueError(
                f'环境【{env}】在回测区间内价格数据不足'
            )

        # 明确不进行隐式前向填充；只使用真实共同有效日收益
        try:
            rets = p.pct_change(fill_method=None)
        except TypeError:
            # 兼容旧 pandas
            rets = p.pct_change()

        rets = rets.replace(
            [np.inf, -np.inf],
            np.nan
        )

        common = rets.dropna(how='any')

        if len(common) < min_common_obs:
            raise ValueError(
                f'环境【{env}】所有候选资产共同有效的日收益只有 '
                f'{len(common)} 条，少于最小要求 {min_common_obs} 条。'
                '请检查资产上市时间/缺失值，或减少候选资产。'
            )

        # 零波动资产会导致相关矩阵不可定义
        std = common.std(ddof=1)
        bad_assets = list(
            std[
                (~np.isfinite(std))
                | (std <= 1e-12)
            ].index
        )
        if bad_assets:
            raise ValueError(
                f'环境【{env}】存在零波动或异常资产：'
                + '、'.join(bad_assets)
            )

        corr_df = common.corr()
        corr_arr = np.asarray(
            corr_df.values,
            dtype=float
        )
        corr_arr = 0.5 * (
            corr_arr + corr_arr.T
        )
        corr_arr = np.clip(
            corr_arr,
            -1.0,
            1.0
        )
        np.fill_diagonal(corr_arr, 1.0)

        corr_df = pd.DataFrame(
            corr_arr,
            index=candidates,
            columns=candidates
        )

        er, eigvals = _effective_rank_from_corr(
            corr_arr
        )

        # 减去极小量，避免 ER=3.0000000000000004 被误ceil成4
        k = int(
            np.ceil(er - 1e-12)
        )
        k = max(
            1,
            min(k, n)
        )

        (
            selected,
            best_logdet,
            best_det_raw,
            comb_count
        ) = _maxdet_subset_exact(
            corr_df,
            k,
            eps=eps
        )

        selected_env_assets[env] = list(selected)

        selection_info[env] = {
            'candidate_assets': list(candidates),
            'selected_assets': list(selected),
            'N_q': int(n),
            'effective_rank': float(er),
            'K_q': int(k),
            'best_logdet': float(best_logdet),
            'best_det_raw': float(best_det_raw),
            'combination_count': int(comb_count),
            'common_obs': int(len(common)),
            'sample_start': (
                str(pd.Timestamp(common.index.min()).date())
                if len(common) else ''
            ),
            'sample_end': (
                str(pd.Timestamp(common.index.max()).date())
                if len(common) else ''
            ),
            'eigenvalues': [
                float(x) for x in eigvals[::-1]
            ],
        }

    # 筛选后仍必须保持四环境完整且互斥
    validate_cross_env_assets(
        selected_env_assets,
        require_nonempty=True
    )

    return selected_env_assets, selection_info


def make_allweather_curve(
        prices,
        env_assets,
        lookback=126,
        freq='M',
        min_obs=None,
        start=None,
        momentum_params=None,
        momentum_k=0.0,
):
    """
    双层桥水全天候：增长 × 通胀交叉四环境。

    四个互斥环境：
        1. 增长超预期 × 通胀超预期
        2. 增长超预期 × 通胀低于预期
        3. 增长低于预期 × 通胀超预期
        4. 增长低于预期 × 通胀低于预期

    结构：
        第一层：
            每个交叉环境内部做风险预算。
            - momentum_params is None：环境内等风险预算；
            - momentum_params is not None：继续沿用原文件的
              L_mu / L_sigma -> 预测IR -> 国君公式(18) -> 风险预算。

        第二层：
            将第一层得到的四个环境组合视为 Y1, Y2, Y3, Y4，
            对四个环境组合做等风险预算 / 风险平价。

    关键变化：
        每个真实资产只能属于一个交叉环境，因此不会再出现
        同一资产同时进入两个环境组合、进而在第二层形成重复暴露。
    """
    if min_obs is None:
        min_obs = lookback

    # 严格保证四环境完整、且资产互斥
    validate_cross_env_assets(
        env_assets,
        require_nonempty=True
    )

    # 固定环境顺序，保证 Y1~Y4 的顺序稳定
    env_assets = {
        env: list(env_assets[env])
        for env in CROSS_MACRO_ENVS
    }

    use_momentum = momentum_params is not None

    # ============================================================
    # 所有真实资产：由于前面已校验互斥，这里不会重复
    # ============================================================
    all_assets = [
        asset
        for env in CROSS_MACRO_ENVS
        for asset in env_assets[env]
    ]

    n = len(all_assets)

    if n == 0:
        raise ValueError('全天候未分配任何资产')

    if use_momentum:
        missing = [
            a for a in all_assets
            if a not in momentum_params
        ]
        if missing:
            raise ValueError(
                '以下资产缺少动量参数：'
                + ', '.join(missing)
            )

    # ============================================================
    # 资产日收益率
    # ============================================================
    rets = (
        prices[all_assets]
        .pct_change()
        .replace([np.inf, -np.inf], np.nan)
    )

    days = _rebal_days(freq, rets)

    loop_index = (
        rets.index[rets.index >= start]
        if start is not None
        else rets.index
    )

    w_cur = None
    out = []
    w_hist = {}

    # ============================================================
    # 正式回测
    # ============================================================
    for d in loop_index:

        if d in days:
            idx = rets.index.get_loc(d)

            # 配权协方差只使用调仓日前数据
            win = rets.iloc[
                max(0, idx - lookback):idx
            ]

            if len(win) >= min_obs:

                # =================================================
                # 第一层：四个交叉宏观环境内部
                # =================================================
                env_inner_weights = {}
                env_return_series = {}

                for env in CROSS_MACRO_ENVS:
                    assets_env = env_assets[env]
                    active_env = []

                    for a in assets_env:

                        # 协方差历史长度检查
                        if win[a].notna().sum() < min_obs:
                            continue

                        # 动量增强时，还需满足自己的 L_mu / L_sigma
                        if use_momentum:
                            pars = momentum_params[a]
                            L_mu = int(pars['L_mu'])
                            L_sigma = int(pars['L_sigma'])

                            ir_test = calc_momentum_ir(
                                rets=rets,
                                asset=a,
                                idx=idx,
                                L_mu=L_mu,
                                L_sigma=L_sigma,
                            )

                            if np.isnan(ir_test):
                                continue

                        active_env.append(a)

                    if not active_env:
                        continue

                    # 环境内部资产必须使用共同有效样本
                    sub = (
                        win[active_env]
                        .dropna(how='any')
                    )

                    if len(sub) < min_obs:
                        continue

                    m = len(active_env)

                    # ---------------------------------------------
                    # 第一层风险预算
                    # ---------------------------------------------
                    if m == 1:
                        a_env = np.array([1.0])

                    else:
                        cov_env = sub.cov().values

                        if not use_momentum:
                            # 原始全天候：环境内部等风险预算
                            b_env_inner = np.ones(m) / m

                        else:
                            # 动量增强：完全保留原文件逻辑
                            # L_mu/L_sigma -> IR -> 公式(18) -> b_i
                            b_env_inner, ir_map = momentum_risk_budgets(
                                rets=rets,
                                assets=active_env,
                                idx=idx,
                                momentum_params=momentum_params,
                                momentum_k=momentum_k,
                            )

                            if b_env_inner is None:
                                continue

                        a_env = risk_budget_weights(
                            cov_env,
                            b_env_inner
                        )
                        a_env = np.asarray(
                            a_env,
                            dtype=float
                        ).ravel()

                    env_inner_weights[env] = {
                        'assets': active_env,
                        'weights': a_env
                    }

                    # 这就是第二层使用的环境组合历史收益 Y_e
                    env_return_series[env] = (
                        sub[active_env] @ a_env
                    )

                # =================================================
                # 第一层结束
                # 必须四个环境全部形成，才进入第二层。
                # 不再临时用“3个环境”或“2个环境”替代四环境模型。
                # =================================================
                active_envs = [
                    env for env in CROSS_MACRO_ENVS
                    if env in env_inner_weights
                ]

                if len(active_envs) == len(CROSS_MACRO_ENVS):

                    # =============================================
                    # 第二层：Y1~Y4 宏观环境组合风险平价
                    # =============================================
                    env_ret_df = pd.concat(
                        {
                            env: env_return_series[env]
                            for env in CROSS_MACRO_ENVS
                        },
                        axis=1
                    ).dropna(how='any')

                    if len(env_ret_df) >= min_obs:
                        cov_env_level = (
                            env_ret_df
                            .cov()
                            .values
                        )

                        # 四个宏观环境目标风险贡献均为 1/4
                        b_env_level = (
                            np.ones(len(CROSS_MACRO_ENVS))
                            / len(CROSS_MACRO_ENVS)
                        )

                        w_env = risk_budget_weights(
                            cov_env_level,
                            b_env_level
                        )
                        w_env = np.asarray(
                            w_env,
                            dtype=float
                        ).ravel()

                        # =========================================
                        # 第一层 × 第二层 -> 最终真实资产资金权重
                        #
                        # 因为四环境资产互斥，这里直接赋值，
                        # 不再需要把同一资产来自多个环境的权重相加。
                        # =========================================
                        w = np.zeros(n)

                        for j, env in enumerate(CROSS_MACRO_ENVS):
                            env_weight = w_env[j]
                            assets_env_active = (
                                env_inner_weights[env]['assets']
                            )
                            a_env = (
                                env_inner_weights[env]['weights']
                            )

                            for kk, asset in enumerate(assets_env_active):
                                w[all_assets.index(asset)] = (
                                    env_weight * a_env[kk]
                                )

                        if w.sum() > 0:
                            w = w / w.sum()
                            w_cur = w
                            w_hist[d] = w_cur.copy()

        # 非调仓日继续沿用上一期权重
        ret_d = (
            w_cur
            @ rets.loc[d].fillna(0).values
            if w_cur is not None
            else np.nan
        )

        out.append((d, ret_d))

    pr = pd.Series(dict(out)).sort_index()

    if start is not None:
        pr = pr[pr.index >= start]

    pr = pr.dropna()

    if w_hist:
        wdf = pd.DataFrame(
            list(w_hist.values()),
            index=list(w_hist.keys()),
            columns=all_assets
        ).sort_index()
    else:
        wdf = pd.DataFrame()

    return pr, wdf

def rolls(pr, w):
    nav=(1+pr).cumprod()

    rsh=(
        pr.rolling(w).mean()*252
    ) / (
        pr.rolling(w).std()*np.sqrt(252)
    )

    rd=nav/nav.cummax()-1
    rsv=pr.rolling(w).std()*np.sqrt(252)
    rav=nav/nav.shift(w)-1

    return nav, rsh, rd, rsv, rav


def build_macro_states():
    """Wind 实际 vs 预测 判别超预期; 返回增长状态、CPI通胀状态、PPI通胀状态"""
    def ym(x): return f"{x.year}-{x.month:02d}"

    # ---- PMI ----
    pmi = pd.read_excel("PMI_对齐清理.xlsx").iloc[:, :3]
    pmi.columns = ["date", "PMI_pred", "PMI_act"]
    pmi["date"] = excel_serial_to_datetime(pmi["date"])
    pmi["PMI_pred"] = pd.to_numeric(pmi["PMI_pred"], errors="coerce")
    pmi["PMI_act"] = pd.to_numeric(pmi["PMI_act"], errors="coerce")
    pmi = pmi.dropna(subset=["date","PMI_pred","PMI_act"])
    pmi = pmi[(pmi["PMI_pred"]!=0)&(pmi["PMI_act"]!=0)].set_index("date").sort_index()
    pmi["g_class"] = np.where(pmi["PMI_act"]>pmi["PMI_pred"], "g_up", "g_down")
    macro_g = pmi[["g_class"]].copy()
    macro_g.index = macro_g.index + pd.offsets.MonthEnd(0)
    macro_g.index = macro_g.index.strftime('%Y-%m')

    # ---- CPI ----
    cpi = pd.read_excel("CPI_对齐清理.xlsx")
    if cpi.shape[1] == 4:
        cp = pd.DataFrame({"date": excel_serial_to_datetime(cpi.iloc[:,0]),
                           "CPI_pred": pd.to_numeric(cpi.iloc[:,1],errors="coerce")})
        ca = pd.DataFrame({"date": excel_serial_to_datetime(cpi.iloc[:,2]),
                           "CPI_act": pd.to_numeric(cpi.iloc[:,3],errors="coerce")})
        cpi = cp.merge(ca, on="date", how="inner")
    else:
        cpi = cpi.iloc[:, :3]
        cpi.columns = ["date","CPI_pred","CPI_act"]
        cpi["date"] = excel_serial_to_datetime(cpi["date"])
        cpi["CPI_pred"] = pd.to_numeric(cpi["CPI_pred"],errors="coerce")
        cpi["CPI_act"] = pd.to_numeric(cpi["CPI_act"],errors="coerce")
    cpi = cpi.dropna(subset=["date","CPI_pred","CPI_act"])
    cpi = cpi[(cpi["CPI_pred"]!=0)&(cpi["CPI_act"]!=0)].set_index("date").sort_index()
    cpi["i_class"] = np.where(cpi["CPI_act"]>cpi["CPI_pred"], "i_up", "i_down")
    macro_i_cpi = cpi[["i_class"]].copy()
    macro_i_cpi.index = macro_i_cpi.index + pd.offsets.MonthEnd(0)
    macro_i_cpi.index = macro_i_cpi.index.strftime('%Y-%m')

    # ---- PPI ----
    ppi = pd.read_excel("PPI对齐清理.xlsx")
    if ppi.shape[1] == 4:
        pp = pd.DataFrame({"date": excel_serial_to_datetime(ppi.iloc[:,0]),
                           "PPI_pred": pd.to_numeric(ppi.iloc[:,1],errors="coerce")})
        pa = pd.DataFrame({"date": excel_serial_to_datetime(ppi.iloc[:,2]),
                           "PPI_act": pd.to_numeric(ppi.iloc[:,3],errors="coerce")})
        ppi = pp.merge(pa, on="date", how="inner")
    else:
        ppi = ppi.iloc[:, :3]
        ppi.columns = ["date","PPI_pred","PPI_act"]
        ppi["date"] = excel_serial_to_datetime(ppi["date"])
        ppi["PPI_pred"] = pd.to_numeric(ppi["PPI_pred"],errors="coerce")
        ppi["PPI_act"] = pd.to_numeric(ppi["PPI_act"],errors="coerce")
    ppi = ppi.dropna(subset=["date","PPI_pred","PPI_act"])
    ppi = ppi.set_index("date").sort_index()
    ppi["i_class"] = np.where(ppi["PPI_act"]>ppi["PPI_pred"], "i_up", "i_down")
    macro_i_ppi = ppi[["i_class"]].copy()
    macro_i_ppi.index = macro_i_ppi.index + pd.offsets.MonthEnd(0)
    macro_i_ppi.index = macro_i_ppi.index.strftime('%Y-%m')

    return macro_g, macro_i_cpi, macro_i_ppi


def dim_judge(mu_up, mu_down, alpha=0.10):
    """
    资产象限判别（新规则）：
    1. 两者都正：μ_up >= μ_down → 'up'；μ_up < μ_down → 'down'
    2. μ_up 正，μ_down 负：若 μ_up + μ_down > 0 → 'up'；否则不放
    3. μ_up 负，μ_down 正：若 μ_up + μ_down > 0 → 'down'；否则不放
    4. 两者都负：不放
    """
    if np.isnan(mu_up) or np.isnan(mu_down):
        return []

    up_pos = mu_up > 0
    down_pos = mu_down > 0

    if up_pos and down_pos:
        if mu_up >= mu_down:
            return ['up']
        else:
            return ['down']

    if up_pos and not down_pos and mu_down < 0:
        if mu_up + mu_down > 0:
            return ['up']
        else:
            return []

    if not up_pos and mu_up < 0 and down_pos:
        if mu_up + mu_down > 0:
            return ['down']
        else:
            return []

    return []

    
def auto_assign(prices, sel_assets):
    """
    自动判定“增长 × 通胀”交叉四环境。

    先完全沿用原文件的两个维度判别方法：
        增长维度 -> up / down
        通胀维度 -> up / down

    然后将两个维度交叉：
        (g_up, i_up)     -> 增长超预期 × 通胀超预期
        (g_up, i_down)   -> 增长超预期 × 通胀低于预期
        (g_down, i_up)   -> 增长低于预期 × 通胀超预期
        (g_down, i_down) -> 增长低于预期 × 通胀低于预期

    如果某资产在任一维度无法得到明确分类，则该资产不进入全天候资产池。
    因此每个被纳入的资产最多只属于一个交叉环境。
    """
    macro_g, macro_i_cpi, macro_i_ppi = build_macro_states()
    start_dt = pd.Period(macro_g.index.min(), freq='M').start_time

    p = prices.loc[
        prices.index >= start_dt,
        sel_assets
    ].copy()

    p = p.ffill()

    monthly = p.resample('ME').last()
    ret = monthly.pct_change().iloc[1:]
    ret.index = ret.index.to_period('M').astype(str)

    # ------------------------------------------------------------
    # 读取 CPI / PPI 代理选择文件（保持原逻辑）
    # ------------------------------------------------------------
    proxy_df = pd.read_excel(
        "CPI_PPI标准化环比回归结果.xlsx",
        sheet_name="Standardized_Regression"
    )

    required_cols = {"资产", "CPI_R2", "PPI_R2"}
    missing = required_cols - set(proxy_df.columns)

    if missing:
        raise ValueError(
            f"代理文件缺少列: {sorted(missing)}"
        )

    proxy_df["CPI_R2"] = pd.to_numeric(
        proxy_df["CPI_R2"],
        errors="coerce"
    )
    proxy_df["PPI_R2"] = pd.to_numeric(
        proxy_df["PPI_R2"],
        errors="coerce"
    )

    proxy_map = {}

    for _, row in proxy_df.iterrows():
        asset = row["资产"]
        cpi_r2 = row["CPI_R2"]
        ppi_r2 = row["PPI_R2"]

        if pd.isna(cpi_r2) and pd.isna(ppi_r2):
            raise ValueError(
                f"资产【{asset}】的 CPI_R2 和 PPI_R2 都是缺失值"
            )

        if pd.isna(cpi_r2):
            proxy = "PPI"
        elif pd.isna(ppi_r2):
            proxy = "CPI"
        elif ppi_r2 > cpi_r2:
            proxy = "PPI"
        else:
            proxy = "CPI"

        proxy_map[asset] = proxy

    missing_assets = [
        a for a in sel_assets
        if a not in proxy_map
    ]

    if missing_assets:
        raise ValueError(
            "以下资产在代理文件中未找到: "
            + ", ".join(missing_assets)
        )

    def get_mp(ddf, cc, cl, col):
        sub = ddf[
            ddf[cc] == cl
        ][col].dropna()

        if len(sub) < 3:
            return np.nan, np.nan

        mu = sub.mean() * 100
        se = sub.std(ddof=1) / np.sqrt(len(sub))
        t = mu / (se * 100) if se > 0 else np.nan

        if not np.isnan(t):
            pval = (
                1 - stats.t.cdf(t, df=len(sub)-1)
                if mu > 0
                else stats.t.cdf(t, df=len(sub)-1)
            )
        else:
            pval = np.nan

        return mu, pval

    # 增长维度样本
    alg_g = (
        ret.join(macro_g, how='inner')
        .dropna(subset=['g_class'])
    )

    # 最终只保留四个“交叉且互斥”的环境
    env_assets = {
        env: []
        for env in CROSS_MACRO_ENVS
    }

    for col in sel_assets:

        # ========================================================
        # A. 增长维度：完全沿用原 dim_judge
        # ========================================================
        g_um, _ = get_mp(
            alg_g,
            'g_class',
            'g_up',
            col
        )
        g_dm, _ = get_mp(
            alg_g,
            'g_class',
            'g_down',
            col
        )

        g_state = dim_judge(
            g_um,
            g_dm
        )

        # ========================================================
        # B. 通胀维度：仍按原文件先选 CPI/PPI 代理
        # ========================================================
        proxy = proxy_map[col]

        macro_i = (
            macro_i_cpi
            if proxy == "CPI"
            else macro_i_ppi
        )

        alg_i = (
            ret.join(macro_i, how='inner')
            .dropna(subset=['i_class'])
        )

        i_um, _ = get_mp(
            alg_i,
            'i_class',
            'i_up',
            col
        )
        i_dm, _ = get_mp(
            alg_i,
            'i_class',
            'i_down',
            col
        )

        i_state = dim_judge(
            i_um,
            i_dm
        )

        # ========================================================
        # C. 两个维度交叉
        # dim_judge 当前最多返回一个方向。
        # 任一维度无明确方向 -> 不纳入。
        # ========================================================
        if len(g_state) != 1 or len(i_state) != 1:
            continue

        env = CROSS_ENV_MAP[
            (
                g_state[0],
                i_state[0]
            )
        ]

        env_assets[env].append(col)

    # 理论上此时不会重复；再做一次硬校验，防止后续改代码时破坏约束
    validate_cross_env_assets(
        env_assets,
        require_nonempty=False
    )

    return env_assets

# ============ GUI ============
class App:
    def __init__(self, root, prices):
        self.root=root; self.prices=prices; self.assets=list(prices.columns); self.curves={}
        self.palette=[plt.cm.tab20(i) for i in range(20)]
        self._undo_curves=None
        self.rb_budgets = None
        self.page=0   # 当前页(0=核心4图,1=日收益,2=整体指标)
        root.title('动态交互回测对比(分页)'); root.geometry('1180x820')
        left=tk.Frame(root); left.pack(side=tk.LEFT, fill=tk.Y, padx=5, pady=5)
        tk.Label(left,text='1. 选择资产').pack(anchor='w')
        cbr=tk.Frame(left); cbr.pack(anchor='w')
        self.asset_vars={}
        canvas=tk.Canvas(cbr,height=300,width=160); sbar=tk.Scrollbar(cbr,orient='vertical',command=canvas.yview)
        inner=tk.Frame(canvas)
        inner.bind('<Configure>',lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.create_window((0,0),window=inner,anchor='nw'); canvas.configure(yscrollcommand=sbar.set)
        canvas.pack(side=tk.LEFT); sbar.pack(side=tk.RIGHT,fill=tk.Y)
        for a in self.assets:
            v=tk.BooleanVar(value=True); tk.Checkbutton(inner,text=a,variable=v).pack(anchor='w'); self.asset_vars[a]=v
        selbtn=tk.Frame(left); selbtn.pack(anchor='w')
        tk.Button(selbtn,text='全选',command=lambda: self._set_all(True)).pack(side=tk.LEFT,padx=2)
        tk.Button(selbtn,text='全不选',command=lambda: self._set_all(False)).pack(side=tk.LEFT,padx=2)
        tk.Label(left,text='2. 配权方式').pack(anchor='w',pady=(10,0))

        self.meth_keys={'等权':'equal','波动率倒数比':'invvol','风险平价':'riskpar','风险预算':'rb'}
        self.meth_vars={}
        for name,k in self.meth_keys.items():
            v=tk.BooleanVar(value=True); tk.Checkbutton(left,text=name,variable=v).pack(anchor='w'); self.meth_vars[k]=v
        tk.Label(left,text='3. 参数').pack(anchor='w',pady=(10,0))
        tk.Label(left,text='配权窗口(交易日,默认126):').pack(anchor='w')
        self.e_look=tk.Entry(left); self.e_look.insert(0,'126'); self.e_look.pack(anchor='w')
        tk.Label(left,text='滚动指标窗口(默认252):').pack(anchor='w')
        self.e_roll=tk.Entry(left); self.e_roll.insert(0,'252'); self.e_roll.pack(anchor='w')


        tk.Label(left,text='调仓频率(日D/月M/季Q):').pack(anchor='w')
        self.e_freq=tk.Entry(left); self.e_freq.insert(0,'M'); self.e_freq.pack(anchor='w')

        tk.Label(left,text='回测起始日期(YYYY-MM-DD,留空=全部):').pack(anchor='w')
        self.e_start=tk.Entry(left); self.e_start.insert(0,''); self.e_start.pack(anchor='w')

        tk.Label(
            left,
            text='杠杆融资利率(年化,默认0.03):'
        ).pack(anchor='w')

        self.e_rf=tk.Entry(left); self.e_rf.insert(0,'0.03'); self.e_rf.pack(anchor='w')


        btncol=tk.Frame(left); btncol.pack(anchor='w',pady=(10,0),fill=tk.X)
        for text,cmd in [('添加曲线',self.add),
                         ('桥水全天候(交叉手动)',self.add_allweather),
                         ('桥水全天候(交叉自动)',self.add_allweather_auto),
                         ('清空全部',self.clear)]:
            tk.Button(btncol,text=text,command=cmd,width=22).pack(anchor='w',pady=2,fill=tk.X)



        
        right=tk.Frame(root); right.pack(side=tk.RIGHT,fill=tk.BOTH,expand=True,padx=5,pady=5)
        tk.Label(right,text='已添加曲线').pack(anchor='w')
        filt=tk.Frame(right); filt.pack(anchor='w',fill=tk.X)
        tk.Label(filt,text='过滤:').pack(side=tk.LEFT)
        self.filter_var=tk.StringVar()
        fe=tk.Entry(filt,textvariable=self.filter_var)
        fe.pack(side=tk.LEFT,expand=True,fill=tk.X)
        self.filter_var.trace_add('write', lambda *a: self._refresh_list())
        self.listbox = ttk.Treeview(right, columns=('color','ann','mdd'),
                            show='tree headings', height=6)
        self.listbox.heading('#0', text='曲线')
        self.listbox.heading('color', text='颜色'); self.listbox.column('color', width=50, anchor='center')
        self.listbox.heading('ann', text='年化收益'); self.listbox.column('ann', width=90, anchor='center')
        self.listbox.heading('mdd', text='最大回撤'); self.listbox.column('mdd', width=90, anchor='center')
        self.listbox.pack(fill=tk.X)
        # 交互增强: 双击查看权重 + 右键菜单
        self.listbox.bind('<Double-Button-1>', self._on_double_click)
        self.listbox.bind('<Button-3>', self._on_right_click)
        btnrow=tk.Frame(right); btnrow.pack(anchor='w')
        tk.Button(btnrow,text='删除选中曲线',command=self.del_sel).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='重命名选中曲线',command=self.rename_sel).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='对选中加杠杆',command=self.lever_sel).pack(side=tk.LEFT,padx=2)
        tk.Button(
            btnrow,
            text='对选中加动量',
            command=self.add_momentum_sel
        ).pack(
            side=tk.LEFT,
            padx=2
        )

        tk.Button(btnrow,text='查看年度行情',command=self.view_yearly).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='查看权重',command=self.view_weight).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='对比年度行情',command=self.compare_yearly).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='整体指标图',command=self.overall_charts).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='月度热力图',command=self.heatmap_monthly).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='单资产对比',command=self.eq_compare).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='加交易成本',command=self.add_cost).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='风险指标',command=self.risk_metrics).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='相关性矩阵',command=self.corr_matrix).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='雷达图',command=self.radar_chart).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='网格搜索',command=self.grid_search).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='导出选中',command=self.export_sel).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='曲线对比',command=self.curve_compare).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='导出全部',command=self.export_all).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='保存配置',command=self.save_config).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='加载配置',command=self.load_config).pack(side=tk.LEFT,padx=2)
        tk.Button(btnrow,text='撤销',command=self.undo).pack(side=tk.LEFT,padx=2)
        
        # 翻页按钮
        pgrow=tk.Frame(right); pgrow.pack(anchor='w',pady=3)
        self.btn_prev=tk.Button(pgrow,text='◀ 上一页',command=lambda:self.turn_page(-1))
        self.btn_prev.pack(side=tk.LEFT,padx=2)
        self.lbl_page=tk.Label(pgrow,text='页 1/3')
        self.lbl_page.pack(side=tk.LEFT,padx=4)
        self.btn_next=tk.Button(pgrow,text='下一页 ▶',command=lambda:self.turn_page(1))
        self.btn_next.pack(side=tk.LEFT,padx=2)
        # figure 容器
        self.fig_frame=tk.Frame(right); self.fig_frame.pack(fill=tk.BOTH,expand=True)
        self.canvas=None
        self.fig=None; self.axes=None
        self._press=None
        self._build_page()   # 建立第0页

    def _set_all(self, val):
        for a,v in self.asset_vars.items():
            v.set(val)

    # ★ 解析起始日期(留空返回None, 填了则解析成日期)
    def _cur_start(self):
        txt = self.e_start.get().strip()
        if not txt:
            return None
        try:
            return pd.to_datetime(txt)
        except Exception:
            raise ValueError(f'起始日期格式错误: {txt} (请用 YYYY-MM-DD)')

    def _build_page(self, roll=None):
        # 销毁旧canvas
        if self.canvas is not None:
            self.canvas.get_tk_widget().destroy()
            plt.close(self.fig)
        # 重建当前页: 0/1页为2x2, 2页(整体指标)为1x1
        if self.page==2:
            self.fig,self.axes=plt.subplots(1,1,figsize=(11,8))
            self.axes=np.array([[self.axes]])
        else:
            self.fig,self.axes=plt.subplots(2,2,figsize=(11,8))
        self.canvas=FigureCanvasTkAgg(self.fig,master=self.fig_frame)
        self.canvas.get_tk_widget().pack(fill=tk.BOTH,expand=True)
        # 绑定缩放
        self.canvas.mpl_connect('button_press_event',self._on_press)
        self.canvas.mpl_connect('button_release_event',self._on_release)
        self.canvas.mpl_connect('scroll_event',self._on_scroll)
        self.canvas.mpl_connect('key_press_event',self._on_key)
        self.lbl_page.config(text=f'页 {self.page+1}/3')
        self.redraw(self._cur_roll())

    def _cur_roll(self):
        try: return int(self.e_roll.get())
        except: return 252

    def _cur_rf(self):
        try: return float(self.e_rf.get())
        except: return 0.03


    def turn_page(self, delta):
        self.page=(self.page+delta)%3
        self._build_page()

    # ---- 缩放 ----
    def _get_ax(self,event):
        if self.axes is None: return None
        for ax in self.axes.flatten():
            if ax.in_axes(event): return ax
        return None
    def _on_press(self,event):
        if self._get_ax(event) is not None: self._press=(event.xdata,event.ydata)
    def _on_release(self,event):
        if self._press is None: return
        ax=self._get_ax(event)
        if ax is None: self._press=None; return
        x0,y0=self._press; x1,y1=event.xdata,event.ydata
        if None not in (x0,y0,x1,y1):
            xlo,xhi=sorted([x0,x1]); ylo,yhi=sorted([y0,y1])
            if (xhi-xlo)>1e-9 and (yhi-ylo)>1e-9:
                ax.set_xlim(xlo,xhi); ax.set_ylim(ylo,yhi); self.canvas.draw()
        self._press=None
    def _on_scroll(self,event):
        ax=self._get_ax(event)
        if ax is None: return
        sf= 1/1.25 if event.button=='up' else 1.25 if event.button=='down' else None
        if sf is None: return
        xd,yd=event.xdata,event.ydata
        if xd is None or yd is None: return
        xl,yl=ax.get_xlim(),ax.get_ylim()
        nw=(xl[1]-xl[0])*sf; nh=(yl[1]-yl[0])*sf
        rx=(xl[1]-xd)/(xl[1]-xl[0]); ry=(yl[1]-yd)/(yl[1]-yl[0])
        ax.set_xlim([xd-nw*(1-rx),xd+nw*rx]); ax.set_ylim([yd-nh*(1-ry),yd+nh*ry]); self.canvas.draw()
    def _on_key(self,event):
        ax=self._get_ax(event)
        if event.key in ('r','R') and ax is not None:
            ax.autoscale(); self.canvas.draw()

    def ask_budgets(self,assets):
        win=tk.Toplevel(self.root); win.title('设置风险预算'); win.geometry('300x420')
        entries={}
        tk.Label(win,text='逐个资产输入目标预算权重(0~1,自动归一化):').pack(pady=5)
        for a in assets:
            row=tk.Frame(win); row.pack(fill=tk.X,padx=10)
            tk.Label(row,text=a,width=14,anchor='w').pack(side=tk.LEFT)
            e=tk.Entry(row); e.insert(0,''); e.pack(side=tk.LEFT,expand=True,fill=tk.X); entries[a]=e
        h=[None]
        def ok():
            try: vals=[float(entries[a].get()) if entries[a].get() else 0.0 for a in assets]
            except: messagebox.showerror('错误','请输入数字'); return
            if sum(vals)<=0: messagebox.showerror('错误','总和必须>0'); return
            h[0]=np.array(vals); win.destroy()
        tk.Button(win,text='确定',command=ok).pack(pady=8)
        self.root.wait_window(win); return h[0]


    def ask_momentum_settings(self, assets):

        """
        询问动量参数。

        返回：

        (
            momentum_params,
            k
        )

        momentum_params =
        {
            asset: {
                'L_mu': ...,
                'L_sigma': ...
            }
        }
        """

        # 去重，保持原顺序
        assets = list(
            dict.fromkeys(assets)
        )

        # ========================================================
        # 49种动量窗口组合
        # ========================================================

        momentum_windows = [
            21,
            42,
            63,
            84,
            105,
            126,
            252
        ]

        momentum_choices = [
            f'{L_mu}/{L_sigma}'
            for L_mu in momentum_windows
            for L_sigma in momentum_windows
        ]






        # ========================================================
        # 第一步：
        # 是否统一使用 63 / 63
        # ========================================================

        use_default = messagebox.askyesno(
            '设置动量窗口',
            '是否对所有资产统一设置：\n\n'
            'L_mu = 63\n'
            'L_sigma = 63 ？',
            parent=self.root
        )

        # ========================================================
        # 情况1：
        # 全部 63 / 63
        # ========================================================

        if use_default:

            momentum_params = {
                a: {
                    'L_mu': 63,
                    'L_sigma': 63
                }
                for a in assets
            }

        # ========================================================
        # 情况2：
        # 每个资产单独设置
        # ========================================================

        else:

            win = tk.Toplevel(
                self.root
            )

            win.title(
                '逐资产设置动量窗口'
            )

            win.geometry(
                '700x700'
            )

            tk.Label(
                win,
                text=(
                    '请为每个资产独立选择动量参数组合\n'
                    '每个资产均可选择全部49种 L_mu / L_sigma 组合'
                ),

                font=(
                    'Microsoft YaHei',
                    11,
                    'bold'
                )
            ).pack(
                pady=8
            )

            # ----------------------------------------------------
            # 可滚动区域
            # ----------------------------------------------------

            outer = tk.Frame(win)

            outer.pack(
                fill=tk.BOTH,
                expand=True
            )

            canvas = tk.Canvas(
                outer
            )

            scrollbar = tk.Scrollbar(
                outer,
                orient='vertical',
                command=canvas.yview
            )

            inside = tk.Frame(
                canvas
            )

            inside.bind(
                '<Configure>',
                lambda e:
                canvas.configure(
                    scrollregion=
                    canvas.bbox('all')
                )
            )

            canvas.create_window(
                (0, 0),
                window=inside,
                anchor='nw'
            )

            canvas.configure(
                yscrollcommand=
                scrollbar.set
            )

            canvas.pack(
                side=tk.LEFT,
                fill=tk.BOTH,
                expand=True
            )

            scrollbar.pack(
                side=tk.RIGHT,
                fill=tk.Y
            )

            # ----------------------------------------------------
            # 表头
            # ----------------------------------------------------

            header = tk.Frame(
                inside
            )

            header.pack(
                fill=tk.X,
                padx=8,
                pady=3
            )

            tk.Label(
                header,
                text='资产',
                width=26,
                anchor='w'
            ).pack(
                side=tk.LEFT
            )

            tk.Label(
                header,
                text='参数组合 L_mu / L_sigma',
                width=24
            ).pack(
                side=tk.LEFT
            )
            




            entries = {}

            # ----------------------------------------------------
            # 每个资产一行
            # ----------------------------------------------------

            for a in assets:

                row = tk.Frame(
                    inside
                )

                row.pack(
                    fill=tk.X,
                    padx=8,
                    pady=2
                )

                tk.Label(
                    row,
                    text=a,
                    width=26,
                    anchor='w'
                ).pack(
                    side=tk.LEFT
                )

                combo = ttk.Combobox(
                    row,
                    values=momentum_choices,
                    state='readonly',
                    width=20
                )

                combo.set(
                    '63/63'
                )

                combo.pack(
                    side=tk.LEFT,
                    padx=3
                )

                entries[a] = combo



            result = [None]

            # ----------------------------------------------------
            # 确定按钮
            # ----------------------------------------------------

            def ok():

                pars = {}

                try:

                    for a in assets:

                        choice = (
                            entries[a]
                            .get()
                            .strip()
                        )

                        if not choice:

                            raise ValueError(
                                f'{a} 尚未选择参数'
                            )

                        L_mu_text, L_sigma_text = (
                            choice.split('/')
                        )

                        L_mu = int(
                            L_mu_text
                        )

                        L_sigma = int(
                            L_sigma_text
                        )

                        pars[a] = {
                            'L_mu': L_mu,
                            'L_sigma': L_sigma
                        }


                except Exception as e:

                    messagebox.showerror(
                        '错误',
                        str(e),
                        parent=win
                    )

                    return

                result[0] = pars

                win.destroy()

            tk.Button(
                win,
                text='确定',
                command=ok,
                width=16
            ).pack(
                pady=8
            )

            self.root.wait_window(
                win
            )

            if result[0] is None:
                return None

            momentum_params = (
                result[0]
            )

        # ========================================================
        # 第二步：
        # 输入统一 k
        # ========================================================

        k = simpledialog.askfloat(
            '设置动量强度 k',
            '请输入动量强度 k：',
            parent=self.root,
            initialvalue=1.0,
            minvalue=0.0
        )

        if k is None:
            return None

        return (
            momentum_params,
            float(k)
        )



    def _new_name(self,name):
        if name not in self.curves:
            return name
        i=2
        while f'{name}_{i}' in self.curves:
            i+=1
        return f'{name}_{i}'
    
    def lever_sel(self):
        """对选中的曲线加杠杆, 生成一条新曲线(原曲线保留, 可对比)"""

        kb = self.listbox.selection()

        if not kb:
            messagebox.showerror(
                '错误',
                '请先选择要加杠杆的曲线'
            )
            return

        name = kb[0]

        L = simpledialog.askfloat(
            '加杠杆',
            '输入杠杆倍数(>1, 如1.4=借0.4):',
            parent=self.root,
            initialvalue=1.4,
            minvalue=1.0
        )

        if not L:
            return

        rf = self._cur_rf()

        new_pr = leverage_returns(
            self.curves[name]['pr'],
            L,
            rf
        )

        new_name = self._new_name(
            f'{name}_杠杆{L:g}倍'
        )

        if new_name is None:
            return

        self.curves[new_name] = {
            'pr': new_pr,
            'weights': self.curves[name].get(
                'weights',
                pd.DataFrame()
            ),
            'color': self.palette[
                len(self.curves) % 20
            ]
        }

        self._refresh_list()
        self.redraw(
            self._cur_roll()
        )



    def add_momentum_sel(self):

        """
        对已经存在的桥水全天候曲线增加动量。

        原曲线不删除，
        新生成一条动量增强曲线。
        """

        # ========================================================
        # 1. 获取当前选中的曲线
        # ========================================================

        kb = self.listbox.selection()

        if not kb:

            messagebox.showerror(
                '错误',
                '请先选择一条桥水全天候曲线'
            )

            return

        if len(kb) != 1:

            messagebox.showerror(
                '错误',
                '一次只能选择一条曲线'
            )

            return

        old_name = kb[0]

        dat = self.curves[
            old_name
        ]

        # ========================================================
        # 2. 必须是全天候曲线
        # ========================================================

        if (
            dat.get(
                'strategy_type'
            )
            != 'allweather'
        ):

            messagebox.showerror(
                '错误',
                '只有桥水全天候曲线可以加动量'
            )

            return

        if (
            'env_assets'
            not in dat
        ):

            messagebox.showerror(
                '错误',
                '该全天候曲线没有保存增长×通胀交叉四环境信息'
            )

            return

        # ========================================================
        # 3. 读取这条曲线原来的环境归属
        # ========================================================

        env_assets = {
            env: list(lst)

            for env, lst
            in dat[
                'env_assets'
            ].items()
        }

        # ========================================================
        # 4. 找到这条曲线实际涉及的所有资产
        # ========================================================

        all_assets = []

        for env, lst in env_assets.items():

            for a in lst:

                if a not in all_assets:

                    all_assets.append(a)

        if not all_assets:

            messagebox.showerror(
                '错误',
                '该曲线没有可用资产'
            )

            return

        # ========================================================
        # 5. 弹出动量参数设置
        # ========================================================

        setting = (
            self.ask_momentum_settings(
                all_assets
            )
        )

        if setting is None:
            return

        (
            momentum_params,
            momentum_k
        ) = setting

        # ========================================================
        # 6. 使用原曲线自己的回测设置
        # ========================================================

        look = dat.get(
            'lookback',
            126
        )

        freq = dat.get(
            'freq',
            'M'
        )

        start = dat.get(
            'start',
            None
        )


        # ========================================================
        # 7. 重新计算动量全天候
        # ========================================================

        try:

            pr, wdf = (
                make_allweather_curve(
                    self.prices,
                    env_assets,

                    lookback=
                    look,

                    freq=
                    freq,

                    start=
                    start,

                    momentum_params=
                    momentum_params,

                    momentum_k=
                    momentum_k,

                )
            )

        except Exception as e:

            messagebox.showerror(
                '错误',
                '动量计算失败：'
                + str(e)
            )

            return

        # ========================================================
        # 8. 生成新的曲线
        # ========================================================

        new_name = self._new_name(
            f'{old_name}+动量'
            f'(k={momentum_k:g})'
        )

        if new_name is None:
            return

        self.curves[new_name] = {

            'pr':
            pr,

            'weights':
            wdf,

            'color':
            self.palette[
                len(self.curves) % 20
            ],

            'strategy_type':
            'allweather',

            'allweather_mode':
            dat.get(
                'allweather_mode',
                'unknown'
            ),

            'macro_structure':
            dat.get(
                'macro_structure',
                'growth_x_inflation'
            ),

            'env_assets': {
                env: list(lst)
                for env, lst
                in env_assets.items()
            },

            # 如果原曲线经过 ER + MaxDet 静态筛选，则完整继承筛选元数据
            'env_assets_candidates':
            dat.get(
                'env_assets_candidates',
                {
                    env: list(lst)
                    for env, lst in env_assets.items()
                }
            ),

            'asset_selection_method':
            dat.get(
                'asset_selection_method',
                None
            ),

            'asset_selection_info':
            dat.get(
                'asset_selection_info',
                None
            ),

            'lookback':
            look,

            'freq':
            freq,

            'start':
            start,


            'momentum':
            True,

            'momentum_params':
            momentum_params,

            'momentum_k':
            momentum_k
        }

        self._refresh_list()

        self.listbox.selection_set(
            new_name
        )

        self.redraw(
            self._cur_roll()
        )





    def rename_sel(self):
        kb=self.listbox.selection()
        if not kb: messagebox.showerror('错误','请先选择要重命名的曲线'); return
        old=kb[0]
        new=simpledialog.askstring('重命名曲线',f'请输入「{old}」的新名称：',parent=self.root,initialvalue=old)
        if not new: messagebox.showinfo('已取消','已取消'); return
        if new in self.curves and new!=old: messagebox.showerror('错误',f'「{new}」已存在'); return
        dat=self.curves.pop(old); self.curves[new]=dat
        self._refresh_list()
        self.listbox.selection_set(new)
        self.redraw(self._cur_roll())

    def view_yearly(self):
        """查看选中曲线的年度行情: 表格 + 柱状图"""
        kb = self.listbox.selection()
        if not kb:
            messagebox.showerror('错误', '请先选择一条曲线'); return
        name = kb[0]
        pr = self.curves[name]['pr']
        yr = yearly_report(pr)
        if yr.empty:
            messagebox.showerror('错误', '该曲线无年度数据'); return

        # 弹出窗口
        win = tk.Toplevel(self.root); win.title(f'{name} - 年度行情'); win.geometry('900x650')
        # 上半: 年度指标表格
        tk.Label(win, text=f'{name} 年度行情指标表', font=('Microsoft YaHei',12,'bold')).pack(pady=5)
        tf = tk.Frame(win); tf.pack(fill=tk.BOTH, expand=True, padx=10)
        cols = ['年化收益率','年化波动率','年化夏普率','最大回撤','卡玛比率','交易日数']
        tree = ttk.Treeview(tf, columns=['年份']+cols, show='headings', height=10)
        tree.heading('年份', text='年份')
        for c in cols:
            tree.heading(c, text=c); tree.column(c, width=90, anchor='center')
        tree.column('年份', width=60, anchor='center')
        for y, row in yr.iterrows():
            vals = [str(y)]
            for c in cols:
                v = row[c]
                if pd.isna(v):
                    vals.append('—')
                elif c in ('年化收益率','年化波动率','最大回撤'):
                    vals.append(f'{v*100:.2f}%')
                else:
                    vals.append(f'{v:.2f}')
            tree.insert('', 'end', values=vals)
        tree.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # 下半: 柱状图 (5个子图)
        fig, axes = plt.subplots(1, 5, figsize=(15, 4))
        metrics = ['年化收益率','年化波动率','年化夏普率','最大回撤','卡玛比率']
        for ax, met in zip(axes, metrics):
            vals = yr[met].fillna(0).values
            ax.bar(yr.index.astype(str), vals, color='#4C9F70' if met!='最大回撤' else '#D9534F')
            ax.set_title(met, fontsize=10)
            ax.tick_params(axis='x', rotation=45, labelsize=7)
            for i, v in enumerate(vals):
                if met in ('年化收益率','年化波动率','最大回撤'):
                    ax.text(i, v, f'{v*100:.1f}%', ha='center', va='bottom' if v>=0 else 'top', fontsize=6)
                else:
                    ax.text(i, v, f'{v:.1f}', ha='center', va='bottom' if v>=0 else 'top', fontsize=6)
        plt.tight_layout()
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

    def _menu_ops(self):
        """构建右键菜单项"""
        m=tk.Menu(self.root, tearoff=0)
        kb=self.listbox.selection()
        if not kb:
            m.add_command(label='无选中曲线', state=tk.DISABLED)
            return m
        m.add_command(label='查看权重', command=self.view_weight)
        m.add_command(label='查看年度行情', command=self.view_yearly)
        m.add_command(label='风险指标', command=self.risk_metrics)
        m.add_separator()
        m.add_command(label='重命名选中', command=self.rename_sel)
        m.add_command(label='对选中加杠杆', command=self.lever_sel)
        m.add_command(
            label='对选中加动量',
            command=self.add_momentum_sel
        )

        m.add_command(label='删除选中', command=self.del_sel)
        return m

    def _on_right_click(self, event):
        # 右键时选中该曲线
        iid=self.listbox.identify_row(event.y)
        if iid:
            self.listbox.selection_set(iid)
        self._menu_ops().tk_popup(event.x_root, event.y_root)

    def _on_double_click(self, event):
        # 双击查看权重
        iid=self.listbox.identify_row(event.y)
        if iid:
            self.listbox.selection_set(iid)
            self.view_weight()
            
    def view_weight(self):
        """查看选中曲线的权重分配比例图(直接读保存的权重,不重新算)"""
        kb = self.listbox.selection()
        if not kb:
            messagebox.showerror('错误', '请先选择一条曲线'); return
        name = kb[0]
        if 'weights' not in self.curves[name] or self.curves[name]['weights'].empty:
            messagebox.showerror('错误', '该曲线无权重数据(可能无调仓)'); return
        wdf = self.curves[name]['weights']

        win = tk.Toplevel(self.root); win.title(f'{name} - 权重分配')
        # 用一个大图
        fig, ax = plt.subplots(figsize=(12, 6))
        # 堆叠面积图: 权重随时间变化
        x = range(len(wdf))
        if len(wdf.index) > 1:
            # 堆叠
            wdf_cum = wdf.fillna(0).cumsum(axis=1)
            wdf_f = wdf.fillna(0)
            colors = plt.cm.tab20(np.linspace(0, 1, wdf.shape[1]))
            prev = np.zeros(len(wdf))
            for i, col in enumerate(wdf_f.columns):
                ax.fill_between(x, prev, prev + wdf_f[col].values,
                                label=col, color=colors[i], alpha=0.7)
                prev = prev + wdf_f[col].values
            ax.set_xticks(x)
            ax.set_xticklabels([pd.Timestamp(t).strftime('%Y-%m') for t in wdf.index], rotation=90, fontsize=8)
            ax.set_ylim(0, 1)
        else:
            # 只有一个调仓日 -> 饼图
            wrow = wdf.iloc[0]
            ax.pie(wrow.values, labels=wrow.index, autopct='%1.1f%%')
            ax.set_title(f'{name} - 权重分配')
        ax.set_title(f'{name} - 权重随时间变化'); ax.legend(loc='center left', bbox_to_anchor=(1, 0.5), fontsize=8)
        plt.tight_layout()
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        


    def _show_static_selection_result(
            self,
            selection_info,
            title='Effective Rank + MaxDet 静态资产筛选',
    ):
        """
        弹窗显示每个环境的：
        候选资产数 N_q、Effective Rank、K_q、MaxDet最终入选资产。
        """
        lines = [
            '全样本静态资产筛选完成：',
            '',
            '规则：K_q = ceil(Effective Rank)，',
            '再在所有 K_q 资产子集中最大化相关矩阵 log-det。',
            '筛选后资产池在整个回测期间固定不变。',
            ''
        ]

        for env in CROSS_MACRO_ENVS:
            info = selection_info[env]
            lines.append(f'【{env}】')
            lines.append(
                f'  N_q={info["N_q"]}，'
                f'ER_q={info["effective_rank"]:.4f}，'
                f'K_q={info["K_q"]}'
            )
            lines.append(
                f'  共同有效样本={info["common_obs"]}日 '
                f'({info["sample_start"]} ~ {info["sample_end"]})'
            )
            lines.append(
                f'  穷举组合数={info["combination_count"]}，'
                f'最优 det={info["best_det_raw"]:.8f}'
            )
            lines.append(
                '  候选：'
                + '、'.join(info['candidate_assets'])
            )
            lines.append(
                '  入选：'
                + '、'.join(info['selected_assets'])
            )
            lines.append('')

        messagebox.showinfo(
            title,
            '\n'.join(lines),
            parent=self.root
        )

    def add_allweather(self):
        try:
            look = int(self.e_look.get())
        except:
            messagebox.showerror('错误', '窗口需为整数')
            return

        freq = self.e_freq.get().strip() or 'M'

        selected_assets = [
            a for a, v in self.asset_vars.items()
            if v.get()
        ]

        if not selected_assets:
            messagebox.showerror(
                '错误',
                '请先在左侧至少勾选一个资产'
            )
            return

        win = tk.Toplevel(self.root)
        win.title('桥水全天候：增长 × 通胀交叉四环境')
        win.geometry('760x650')

        tk.Label(
            win,
            text=(
                '每个资产分别选择“增长状态”和“通胀状态”，'
                '程序会自动交叉成唯一宏观环境。\n'
                '因此同一资产不会再同时进入两个环境。'
            ),
            font=('Microsoft YaHei', 11, 'bold')
        ).pack(pady=8)

        outer = tk.Frame(win)
        outer.pack(fill=tk.BOTH, expand=True)

        canvas = tk.Canvas(outer)
        scrollbar = tk.Scrollbar(
            outer,
            orient='vertical',
            command=canvas.yview
        )

        inside = tk.Frame(canvas)
        inside.bind(
            '<Configure>',
            lambda e: canvas.configure(
                scrollregion=canvas.bbox('all')
            )
        )

        canvas.create_window(
            (0, 0),
            window=inside,
            anchor='nw'
        )
        canvas.configure(
            yscrollcommand=scrollbar.set
        )

        canvas.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )
        scrollbar.pack(
            side=tk.RIGHT,
            fill=tk.Y
        )

        # 表头
        header = tk.Frame(inside)
        header.pack(
            fill=tk.X,
            padx=8,
            pady=4
        )

        tk.Label(
            header,
            text='资产',
            width=24,
            anchor='w'
        ).pack(side=tk.LEFT)

        tk.Label(
            header,
            text='增长维度',
            width=20
        ).pack(side=tk.LEFT)

        tk.Label(
            header,
            text='通胀维度',
            width=20
        ).pack(side=tk.LEFT)

        growth_choices = (
            '不参与',
            '增长超预期',
            '增长低于预期'
        )

        inflation_choices = (
            '不参与',
            '通胀超预期',
            '通胀低于预期'
        )

        growth_vars = {}
        inflation_vars = {}

        for asset in selected_assets:
            row = tk.Frame(inside)
            row.pack(
                fill=tk.X,
                padx=8,
                pady=2
            )

            tk.Label(
                row,
                text=asset,
                width=24,
                anchor='w'
            ).pack(side=tk.LEFT)

            g_combo = ttk.Combobox(
                row,
                values=growth_choices,
                state='readonly',
                width=18
            )
            g_combo.set('不参与')
            g_combo.pack(
                side=tk.LEFT,
                padx=3
            )

            i_combo = ttk.Combobox(
                row,
                values=inflation_choices,
                state='readonly',
                width=18
            )
            i_combo.set('不参与')
            i_combo.pack(
                side=tk.LEFT,
                padx=3
            )

            growth_vars[asset] = g_combo
            inflation_vars[asset] = i_combo

        result = [None]

        def ok():
            env_assets = {
                env: []
                for env in CROSS_MACRO_ENVS
            }

            for asset in selected_assets:
                g = growth_vars[asset].get().strip()
                i = inflation_vars[asset].get().strip()

                # 两个维度都不参与 -> 该资产不纳入
                if g == '不参与' and i == '不参与':
                    continue

                # 只填一个维度会造成定义不完整，直接阻止
                if g == '不参与' or i == '不参与':
                    messagebox.showerror(
                        '错误',
                        f'资产【{asset}】必须同时选择增长和通胀两个维度，'
                        '或者两个维度都选择“不参与”。',
                        parent=win
                    )
                    return

                g_state = (
                    'up'
                    if g == '增长超预期'
                    else 'down'
                )

                i_state = (
                    'up'
                    if i == '通胀超预期'
                    else 'down'
                )

                env = CROSS_ENV_MAP[
                    (g_state, i_state)
                ]

                env_assets[env].append(asset)

            try:
                validate_cross_env_assets(
                    env_assets,
                    require_nonempty=True
                )
            except Exception as e:
                messagebox.showerror(
                    '错误',
                    str(e),
                    parent=win
                )
                return

            result[0] = env_assets
            win.destroy()

        tk.Button(
            win,
            text='确定',
            command=ok,
            width=16
        ).pack(pady=8)

        self.root.wait_window(win)

        env_assets = result[0]

        if env_assets is None:
            return

        try:
            start = self._cur_start()
        except ValueError as e:
            messagebox.showerror(
                '错误',
                str(e)
            )
            return

        # ========================================================
        # 手动模式：四象限候选资产 -> Effective Rank -> K_q
        #          -> 精确 MaxDet -> 固定资产池
        # ========================================================
        raw_env_assets = {
            env: list(env_assets[env])
            for env in CROSS_MACRO_ENVS
        }

        try:
            env_assets, selection_info = (
                select_static_env_assets_maxdet(
                    prices=self.prices,
                    env_assets=raw_env_assets,
                    start=start
                )
            )
        except Exception as e:
            messagebox.showerror(
                '静态资产筛选失败',
                str(e)
            )
            return

        self._show_static_selection_result(
            selection_info,
            title='手动全天候：ER + MaxDet筛选结果'
        )

        try:
            pr, wdf = make_allweather_curve(
                self.prices,
                env_assets,
                lookback=look,
                freq=freq,
                start=start
            )
        except Exception as e:
            messagebox.showerror(
                '错误',
                str(e)
            )
            return

        name = self._new_name(
            '桥水全天候(交叉手动)'
        )

        if name is None:
            return

        self.curves[name] = {
            'pr': pr,
            'weights': wdf,
            'color': self.palette[
                len(self.curves) % 20
            ],
            'strategy_type': 'allweather',
            'allweather_mode': 'manual',
            'macro_structure': 'growth_x_inflation',
            # env_assets 保存的是 ER + MaxDet 最终固定资产池
            'env_assets': {
                env: list(lst)
                for env, lst in env_assets.items()
            },
            # 保留筛选前候选池和数学筛选结果，方便复核
            'env_assets_candidates': {
                env: list(lst)
                for env, lst in raw_env_assets.items()
            },
            'asset_selection_method': 'effective_rank_maxdet_static',
            'asset_selection_info': selection_info,
            'lookback': look,
            'freq': freq,
            'start': start,
            'momentum': False
        }

        self._refresh_list()
        self.redraw(
            self._cur_roll()
        )

    def add_allweather_auto(self, silent=False):
        try:
            look = int(self.e_look.get())
        except:
            messagebox.showerror(
                '错误',
                '窗口需为整数'
            )
            return

        freq = (
            self.e_freq.get().strip()
            or 'M'
        )

        sel = [
            a for a, v in self.asset_vars.items()
            if v.get()
        ]

        if not sel:
            messagebox.showerror(
                '错误',
                '请至少勾选一个资产'
            )
            return

        # ========================================================
        # 自动判定：先增长/通胀各自判别，再交叉成唯一环境
        # ========================================================
        try:
            env_assets = auto_assign(
                self.prices,
                sel
            )
        except Exception as e:
            messagebox.showerror(
                '错误',
                '自动判定失败: ' + str(e)
            )
            return

        assigned_assets = [
            a
            for env in CROSS_MACRO_ENVS
            for a in env_assets[env]
        ]

        assigned_set = set(assigned_assets)

        unassigned = [
            a for a in sel
            if a not in assigned_set
        ]

        msg_lines = [
            '增长 × 通胀交叉后的自动归属结果：'
        ]

        for env in CROSS_MACRO_ENVS:
            assets_text = (
                ' , '.join(env_assets[env])
                if env_assets[env]
                else '空'
            )
            msg_lines.append(
                f'  {env}: {assets_text}'
            )

        msg_lines.append('')
        msg_lines.append(
            '未能同时确定增长和通胀方向、因此未纳入的资产：'
            + (
                ' , '.join(unassigned)
                if unassigned
                else '无'
            )
        )

        msg = '\n'.join(msg_lines)

        if not silent:
            messagebox.showinfo(
                '自动桥水全天候：交叉四环境',
                msg
            )

        # 四个环境必须完整，才能做真正的第二层四环境风险平价
        try:
            validate_cross_env_assets(
                env_assets,
                require_nonempty=True
            )
        except Exception as e:
            messagebox.showerror(
                '错误',
                str(e)
                + '\n\n请增加/调整左侧勾选资产后再试。'
            )
            return

        try:
            start = self._cur_start()
        except ValueError as e:
            messagebox.showerror(
                '错误',
                str(e)
            )
            return

        # ========================================================
        # 自动模式：自动归属后的候选池
        # -> Effective Rank -> K_q
        # -> 精确 MaxDet -> 固定资产池
        # ========================================================
        raw_env_assets = {
            env: list(env_assets[env])
            for env in CROSS_MACRO_ENVS
        }

        try:
            env_assets, selection_info = (
                select_static_env_assets_maxdet(
                    prices=self.prices,
                    env_assets=raw_env_assets,
                    start=start
                )
            )
        except Exception as e:
            messagebox.showerror(
                '静态资产筛选失败',
                str(e)
            )
            return

        if not silent:
            self._show_static_selection_result(
                selection_info,
                title='自动全天候：ER + MaxDet筛选结果'
            )

        # 后续动量参数只对最终真正入选的固定资产设置
        selected_assets = [
            a
            for env in CROSS_MACRO_ENVS
            for a in env_assets[env]
        ]

        # ========================================================
        # 动量参数：只询问 ER + MaxDet 最终入选资产
        # ========================================================
        momentum_setting = None

        if not silent:
            momentum_setting = (
                self.ask_momentum_settings(
                    selected_assets
                )
            )

        # ========================================================
        # 第一条：原始交叉全天候
        # 第一层环境内等风险预算，第二层四环境风险平价
        # ========================================================
        try:
            pr, wdf = make_allweather_curve(
                self.prices,
                env_assets,
                lookback=look,
                freq=freq,
                start=start
            )
        except Exception as e:
            messagebox.showerror(
                '错误',
                str(e)
            )
            return

        name = self._new_name(
            '桥水全天候(交叉自动判定)'
        )

        if name is None:
            return

        self.curves[name] = {
            'pr': pr,
            'weights': wdf,
            'color': self.palette[
                len(self.curves) % 20
            ],
            'strategy_type': 'allweather',
            'allweather_mode': 'auto',
            'macro_structure': 'growth_x_inflation',
            # env_assets 保存的是 ER + MaxDet 最终固定资产池
            'env_assets': {
                env: list(lst)
                for env, lst in env_assets.items()
            },
            'env_assets_candidates': {
                env: list(lst)
                for env, lst in raw_env_assets.items()
            },
            'asset_selection_method': 'effective_rank_maxdet_static',
            'asset_selection_info': selection_info,
            'lookback': look,
            'freq': freq,
            'start': start,
            'momentum': False
        }

        # silent 模式只生成基础版
        if silent:
            self._refresh_list()
            self.redraw(
                self._cur_roll()
            )
            return

        # 用户取消动量参数窗口时，基础版仍然保留
        if momentum_setting is None:
            self._refresh_list()
            self.redraw(
                self._cur_roll()
            )
            return

        momentum_params, momentum_k = (
            momentum_setting
        )

        # ========================================================
        # 第二条：交叉四环境 + 环境内动量风险预算
        # ========================================================
        try:
            pr_mom, wdf_mom = make_allweather_curve(
                self.prices,
                env_assets,
                lookback=look,
                freq=freq,
                start=start,
                momentum_params=momentum_params,
                momentum_k=momentum_k
            )
        except Exception as e:
            messagebox.showerror(
                '错误',
                '动量全天候计算失败：'
                + str(e)
            )

            self._refresh_list()
            self.redraw(
                self._cur_roll()
            )
            return

        mom_name = self._new_name(
            f'桥水全天候(交叉自动)+动量'
            f'(k={momentum_k:g})'
        )

        self.curves[mom_name] = {
            'pr': pr_mom,
            'weights': wdf_mom,
            'color': self.palette[
                len(self.curves) % 20
            ],
            'strategy_type': 'allweather',
            'allweather_mode': 'auto',
            'macro_structure': 'growth_x_inflation',
            # env_assets 保存的是 ER + MaxDet 最终固定资产池
            'env_assets': {
                env: list(lst)
                for env, lst in env_assets.items()
            },
            'env_assets_candidates': {
                env: list(lst)
                for env, lst in raw_env_assets.items()
            },
            'asset_selection_method': 'effective_rank_maxdet_static',
            'asset_selection_info': selection_info,
            'lookback': look,
            'freq': freq,
            'start': start,
            'momentum': True,
            'momentum_params': momentum_params,
            'momentum_k': momentum_k
        }

        self._refresh_list()
        self.redraw(
            self._cur_roll()
        )

    def add(self, preset_rb=None):
        try: look=int(self.e_look.get())
        except: messagebox.showerror('错误','窗口需为整数'); return
        freq=self.e_freq.get().strip() or 'M'
        sel=[a for a,v in self.asset_vars.items() if v.get()]
        meths=[k for k,v in self.meth_vars.items() if v.get()]
        if not sel: messagebox.showerror('错误','请至少选一个资产'); return
        if not meths: messagebox.showerror('错误','请至少选一种配权方式'); return
        try: start=self._cur_start()
        except ValueError as e: messagebox.showerror('错误',str(e)); return
        for m in meths:
            budgets=None
            if m=='rb':
                # 如果是“加载配置”传进来的风险预算，直接使用，不再弹窗
                if preset_rb:
                    try:
                        budgets = np.array(
                            [float(preset_rb[a]) for a in sel],
                            dtype=float
                        )
                    except Exception:
                        messagebox.showerror(
                            '错误',
                            '配置文件中的风险预算与当前资产不匹配'
                        )
                        return
                else:
                    # 平时手动点击“添加曲线”，仍然正常弹出风险预算窗口
                    budgets=self.ask_budgets(sel)
                    if budgets is None:
                        return

                # 记住本次风险预算，保存配置时一起保存
                self.rb_budgets = {
                    a: float(b) for a, b in zip(sel, budgets)
                }

                name=f'{",".join(sel)} | 风险预算'

            else:
                name=f'{",".join(sel)} | {m}'

            name=self._new_name(name)
            if name is None: continue

            pr,wdf=make_curve(self.prices,sel,m,budgets=budgets,lookback=look,
                              freq=freq,start=start)
            self.curves[name]={'pr':pr,'weights':wdf,'color':self.palette[len(self.curves)%20]}
        self._refresh_list()
        self.redraw(self._cur_roll())
        
    def del_sel(self):
        self._snapshot()
        kb=self.listbox.selection()
        if not kb: return
        for name in kb:
            self.listbox.delete(name)
            self.curves.pop(name,None)
        self.redraw(self._cur_roll())

    def export_sel(self):
        """导出选中的多条曲线的净值到Excel"""
        import datetime
        kb=self.listbox.selection()
        if not kb:
            messagebox.showerror('错误','请先选择曲线'); return
        names=list(kb)
        navs={}
        for n in names:
            navs[n]=(1+self.curves[n]['pr']).cumprod()
        out=pd.DataFrame(navs)
        fn=f'曲线导出_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        out.to_excel(fn)
        messagebox.showinfo('导出成功',f'已导出 {len(names)} 条曲线净值到 {fn}')

    def curve_compare(self):
        """对比两条选中的曲线: 净值 + 回撤"""
        kb=self.listbox.selection()
        if len(kb)!=2:
            messagebox.showerror('错误','请精确选择2条曲线(按住Ctrl多选)'); return
        names=list(kb)
        win=tk.Toplevel(self.root); win.title('曲线对比'); win.geometry('1100x650')
        fig,axes=plt.subplots(2,1,figsize=(11,7),sharex=True)
        for n in names:
            pr=self.curves[n]['pr']
            nav=(1+pr).cumprod()
            dd=nav/nav.cummax()-1
            axes[0].plot(nav.index,nav.values,label=n,lw=1.5)
            axes[1].plot(dd.index,dd.values,label=n,lw=1.2)
        axes[0].set_title('净值对比'); axes[0].legend(); axes[0].grid(alpha=0.3)
        axes[1].set_title('回撤对比'); axes[1].legend(); axes[1].grid(alpha=0.3)
        plt.tight_layout()
        figc=FigureCanvasTkAgg(fig,master=win); figc.get_tk_widget().pack(fill=tk.BOTH,expand=True)


    def export_all(self):
        """导出所有曲线的净值和收益率到Excel"""
        import datetime
        if not self.curves:
            messagebox.showerror('错误','无曲线可导出'); return
        navs={}; rets={}
        for n in self.curves:
            pr=self.curves[n]['pr']
            navs[n]=(1+pr).cumprod()
            rets[n]=pr
        fn=f'全曲线导出_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.xlsx'
        with pd.ExcelWriter(fn) as writer:
            pd.DataFrame(navs).to_excel(writer,sheet_name='净值')
            pd.DataFrame(rets).to_excel(writer,sheet_name='日收益率')
        messagebox.showinfo('导出成功',f'已导出到 {fn}')

    def save_config(self):
        """保存当前GUI设置(资产选择/配权/参数)到json"""
        import json, datetime
        is_aw_auto = any(
            dat.get('strategy_type') == 'allweather'
            and dat.get('allweather_mode') == 'auto'
            for dat in self.curves.values()
        )


        config = {
            '已选资产': [a for a, v in self.asset_vars.items() if v.get()],
            '配权方法': [] if is_aw_auto else [k for k, v in self.meth_vars.items() if v.get()],
            '桥水全天候自动': is_aw_auto,
            '配权窗口': self.e_look.get(),
            '滚动窗口': self.e_roll.get(),
            '调仓频率': self.e_freq.get(),
            '杠杆融资利率': self.e_rf.get(),
            '回测起始日期': self.e_start.get(),
            '风险预算': self.rb_budgets,
        }
        fn = f'配置_{datetime.datetime.now().strftime("%Y%m%d_%H%M%S")}.json'
        with open(fn, 'w', encoding='utf-8') as f:
            json.dump(config, f, ensure_ascii=False, indent=2)
        messagebox.showinfo('保存配置', f'已保存到 {fn}')


    def load_config(self):
        """从json加载配置并应用到GUI"""
        import json
        from tkinter import filedialog
        fn = filedialog.askopenfilename(title='选择配置文件',
                                        filetypes=[('JSON文件','*.json')])
        if not fn: return
        try:
            with open(fn, 'r', encoding='utf-8') as f:
                config = json.load(f)
        except Exception as e:
            messagebox.showerror('错误', f'读取配置失败: {e}'); return

        # 应用已选资产
        if '已选资产' in config:
            sel = set(config['已选资产'])
            for a, v in self.asset_vars.items():
                v.set(a in sel)
        # 应用配权方法
        if '配权方法' in config:
            meth = set(config['配权方法'])
            for k, v in self.meth_vars.items():
                v.set(k in meth)
        # 应用参数
        if '配权窗口' in config: self.e_look.delete(0, tk.END); self.e_look.insert(0, config['配权窗口'])
        if '滚动窗口' in config: self.e_roll.delete(0, tk.END); self.e_roll.insert(0, config['滚动窗口'])
        if '调仓频率' in config:
            fq = config['调仓频率']; freqs = {'日':'D','月':'M','季':'Q','D':'D','M':'M','Q':'Q'}
            fq = freqs.get(fq, fq)
            self.e_freq.delete(0, tk.END); self.e_freq.insert(0, fq)
        if '杠杆融资利率' in config:
            self.e_rf.delete(0, tk.END)
            self.e_rf.insert(0, config['杠杆融资利率'])

        elif '无风险利率' in config:
            self.e_rf.delete(0, tk.END)
            self.e_rf.insert(0, config['无风险利率'])


        if '回测起始日期' in config:
            self.e_start.delete(0, tk.END)
            self.e_start.insert(0, config['回测起始日期'])

        # 读取保存的风险预算
        self.rb_budgets = config.get('风险预算')

        if config.get('桥水全天候自动', False):
            # 桥水全天候配置，只生成全天候
            for v in self.meth_vars.values():
                v.set(False)

            self.add_allweather_auto(silent=True)

        else:
            # 普通策略配置
            self.add(preset_rb=self.rb_budgets)









    def _refresh_list(self):
        """重建曲线列表: 颜色方块 + 年化收益 + 最大回撤 (支持过滤)"""
        self.listbox.delete(*self.listbox.get_children())
        kw=self.filter_var.get().strip()
        for name,dat in self.curves.items():
            if kw and kw not in name:
                continue
            r=annual_report(dat['pr'])
            ann=r['年化收益率']; mdd=r['最大回撤']
            ann_s=f'{ann*100:.1f}%' if not np.isnan(ann) else '—'
            mdd_s=f'{mdd*100:.1f}%' if not np.isnan(mdd) else '—'
            color=dat.get('color','gray')
            if isinstance(color,(tuple,list)):
                color='#%02x%02x%02x' % (int(color[0]*255),int(color[1]*255),int(color[2]*255))
            self.listbox.insert('', 'end', iid=name, text=name,
                                values=('■', ann_s, mdd_s), tags=(name,))
            self.listbox.tag_configure(name, foreground=color)




    def _snapshot(self):
        """保存当前所有曲线快照, 用于撤销"""
        self._undo_curves={n: dict(d, pr=d['pr'].copy(),
                                   weights=d['weights'].copy())
                           for n,d in self.curves.items()}

    def undo(self):
        if not self._undo_curves:
            messagebox.showinfo('撤销','无可撤销操作')
            return
        self.curves=self._undo_curves
        self._undo_curves=None
        self._refresh_list()
        self.redraw(self._cur_roll())
            
        
    def clear(self):
        self._snapshot()
        self.curves={}
        self.listbox.delete(*self.listbox.get_children())
        self.redraw(self._cur_roll())



    def _draw_report(self):
        """第3页: 整体指标表格(直接对比所有已添加曲线, 含杠杆生成的)"""
        ax=self.axes.flatten()[0]
        if not self.curves:
            ax.text(0.5,0.5,'请先添加曲线',ha='center',va='center',fontsize=14)
            ax.axis('off'); self.fig.tight_layout(); self.canvas.draw(); return
        metrics=['年化收益率','年化波动率','年化夏普率','最大回撤','卡玛比率']
        rows=list(self.curves.keys())
        n=len(metrics); m=len(rows)
        values=np.full((m,n),np.nan)
        for i,name in enumerate(rows):
            r=annual_report(self.curves[name]['pr'])
            for j,met in enumerate(metrics):
                values[i,j]=r[met]
        ax.axis('off')
        col_labels=['曲线']+metrics
        cell_text=[]; cell_colors=[]
        for i in range(m):
            line=[rows[i]]; color_line=['#f0f0f0']
            for j in range(n):
                v=values[i,j]
                if np.isnan(v): line.append('—')
                else:
                    if metrics[j] in ('年化收益率','年化波动率','最大回撤'):
                        line.append(f'{v*100:.2f}%')
                    else:
                        line.append(f'{v:.2f}')
                if np.isnan(v): color_line.append('#ffffff')
                elif metrics[j]=='年化收益率':
                    color_line.append('#d9f0d9' if v>=0 else '#f0d9d9')
                elif metrics[j]=='最大回撤':
                    color_line.append('#f0d9d9')
                else:
                    color_line.append('#ffffff')
            cell_text.append(line); cell_colors.append(color_line)
        tbl=ax.table(cellText=cell_text, colLabels=col_labels, cellColours=cell_colors,
                     loc='center', colWidths=[0.30]+[0.14]*n)
        tbl.auto_set_font_size(False); tbl.set_fontsize(11); tbl.scale(1,1.8)
        for (ri,ci),cell in tbl.get_celld().items():
            cell.set_edgecolor('#999999')
            if ri==0:
                cell.set_facecolor('#404040'); cell.set_text_props(color='white',weight='bold')
        ax.set_title(
            '全区间整体指标对比',
            fontsize=14,
            pad=10
        )

        self.fig.tight_layout(); self.canvas.draw()

    def redraw(self, roll):
        if self.axes is None: return
        for ax in self.axes.flatten(): ax.clear()
        if self.page==2:
            self._draw_report()
            return
        if not self.curves: self.canvas.draw(); return
        axs=self.axes.flatten()
        # 页面0: 净值/夏普/回撤/波动
        if self.page==0:
            ax_nav,ax_sh,ax_dd,ax_vol=axs
            for name,dat in self.curves.items():
                pr=dat['pr']
                nav,rsh,rd,rsv,rav=rolls(pr,roll)
                ax_nav.plot(nav.index,nav.values,label=name,color=dat['color'])
                ax_sh.plot(rsh.index,rsh.values,label=name,color=dat['color'])
                ax_dd.plot(rd.index,rd.values,label=name,color=dat['color'])
                ax_vol.plot(rsv.index,rsv.values,label=name,color=dat['color'])
            ax_nav.set_title('累计净值'); ax_nav.legend(fontsize=6); ax_nav.grid(alpha=0.3)
            ax_sh.set_title('滚动夏普率'); ax_sh.legend(fontsize=6); ax_sh.grid(alpha=0.3)
            ax_dd.set_title('滚动回撤'); ax_dd.legend(fontsize=6); ax_dd.grid(alpha=0.3)
            ax_vol.set_title('滚动年化波动率'); ax_vol.legend(fontsize=6); ax_vol.grid(alpha=0.3)
        else:
            # 页1: 日度收益率(两条) + 滚动年化收益率(利用空位ax_e1)
            ax_r1,ax_r2,ax_e1,ax_e2=axs
            for name,dat in self.curves.items():
                pr=dat['pr']
                ax_r1.plot(pr.index,pr.values,label=name,lw=0.5,color=dat['color'])
                ax_r2.plot(pr.index,pr.values,label=name,lw=0.5,color=dat['color'])
                nav,rsh,rd,rsv,rav=rolls(pr,roll)
                ax_e1.plot(rav.index,rav.values,label=name,lw=0.5,color=dat['color'])
            ax_r1.set_title('日度收益率曲线(全段)'); ax_r1.legend(fontsize=5); ax_r1.grid(alpha=0.3); ax_r1.axhline(0,color='gray',lw=0.5)
            ax_r2.set_title('日度收益率曲线(放大区)'); ax_r2.legend(fontsize=5); ax_r2.grid(alpha=0.3); ax_r2.axhline(0,color='gray',lw=0.5)
            ax_e1.set_title(f'滚动年化收益率({roll}日)')
            ax_e1.legend(fontsize=5); ax_e1.grid(alpha=0.3); ax_e1.axhline(0,color='gray',lw=0.5)
            ax_e2.set_visible(False)
        self.fig.tight_layout(); self.canvas.draw()


    def overall_charts(self):
        if not self.curves:
            messagebox.showerror('错误', '请先添加曲线'); return
        metrics = ['年化收益率','年化波动率','年化夏普率','最大回撤','卡玛比率']
        names = list(self.curves.keys())
        vals = np.full((len(names), len(metrics)), np.nan)
        for i, name in enumerate(names):
            r = annual_report(self.curves[name]['pr'])
            for j, m in enumerate(metrics):
                vals[i, j] = r[m]

        win = tk.Toplevel(self.root); win.title('整体指标对比柱状图'); win.geometry('1500x750')
        # 缩小图: 用 16x5.5
        fig, axes = plt.subplots(1, 5, figsize=(16, 5.5))
        for j, met in enumerate(metrics):
            ax = axes[j]
            v = vals[:, j]
            ax.bar(names, np.nan_to_num(v), color='#4C9F70' if met!='最大回撤' else '#D9534F')
            ax.set_title(f'整体{met}', fontsize=12)
            # 资产名: 斜排30度, 右对齐, 字号8
            ax.tick_params(axis='x', rotation=30, labelsize=6)
            for lbl in ax.get_xticklabels():
                lbl.set_ha('right')
            ax.axhline(0, color='gray', lw=0.5)
        fig.suptitle('所有曲线 整体指标对比', fontsize=15)
        plt.tight_layout()
        # 关键: 用 subplots_adjust 给底部留大量空间, 确保资产名显示
        fig.subplots_adjust(bottom=0.35, top=0.90, left=0.05, right=0.97, wspace=0.3)
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True)


    def add_cost(self):
        """对选中曲线模拟交易成本, 生成一条新曲线"""
        kb = self.listbox.selection()
        if not kb:
            messagebox.showerror('错误', '请先选择曲线'); return
        name = kb[0]
        rate = simpledialog.askfloat('交易成本', '输入单边交易成本率(如0.001=0.1%):',
                                     parent=self.root, initialvalue=0.001, minvalue=0.0)
        if rate is None: return
        new_pr = cost_returns(self.curves[name]['pr'], rate)
        new_name = self._new_name(f'{name}_含成本{rate*100:.2f}%')
        if new_name is None: return
        self.curves[new_name] = {'pr': new_pr, 'weights': pd.DataFrame(),
                                 'color': self.palette[len(self.curves)%20]}
        self._refresh_list(); self.redraw(self._cur_roll())


    def risk_metrics(self):
        """显示选中曲线的日收益分布 + 风险指标"""
        kb = self.listbox.selection()
        if not kb:
            messagebox.showerror('错误', '请先选择一条曲线'); return
        name = kb[0]
        pr = self.curves[name]['pr'].dropna()
        if len(pr) < 2:
            messagebox.showerror('错误', '数据不足'); return
        r = annual_report(pr)
        # 额外风险指标
        r_daily = pr
        std = r_daily.std(ddof=1)
        skew = float(stats.skew(r_daily))     # 偏度
        kurt = float(stats.kurtosis(r_daily))  # 峰度(超额)
        var95 = np.percentile(r_daily, 5)     # 95% VaR(5%分位)
        var99 = np.percentile(r_daily, 1)     # 99% VaR(1%分位)
        sortino_dd = r_daily[r_daily < 0].std(ddof=1)
        sortino = (
            r['年化收益率'] / sortino_dd
            if sortino_dd > 0 and not np.isnan(sortino_dd)
            else np.nan
        )


        win = tk.Toplevel(self.root); win.title(f'{name} - 风险指标'); win.geometry('1000x650')
        fig, axes = plt.subplots(1, 2, figsize=(11, 6))
        # 左: 日收益直方图
        axes[0].hist(r_daily*100, bins=60, color='#4C9F70', alpha=0.8, edgecolor='white')
        axes[0].axvline(r_daily.mean()*100, color='red', lw=1.5, label=f'均值\n{r_daily.mean()*100:.3f}%')
        axes[0].set_title(f'{name}\n日收益分布'); axes[0].set_xlabel('日收益率(%)')
        axes[0].legend(); axes[0].grid(alpha=0.3)
        # 右: 指标文字
        axes[1].axis('off')
        lines = [
            f'年化收益率: {r["年化收益率"]*100:.2f}%' if not np.isnan(r['年化收益率']) else '年化收益率: —',
            f'年化波动率: {r["年化波动率"]*100:.2f}%' if not np.isnan(r['年化波动率']) else '年化波动率: —',
            f'夏普比率: {r["年化夏普率"]:.2f}' if not np.isnan(r['年化夏普率']) else '夏普: —',
            f'最大回撤: {r["最大回撤"]*100:.2f}%' if not np.isnan(r['最大回撤']) else '最大回撤: —',
            f'卡玛比率: {r["卡玛比率"]:.2f}' if not np.isnan(r['卡玛比率']) else '卡玛: —',
            f'偏度: {skew:.2f}',
            f'峰度(超额): {kurt:.2f}',
            f'日均收益: {r_daily.mean()*100:.3f}%',
            f'日收益标准差: {std*100:.3f}%',
            f'95% VaR: {var95*100:.2f}%',
            f'99% VaR: {var99*100:.2f}%',
            f'Sortino: {sortino:.2f}' if not np.isnan(sortino) else 'Sortino: —',
        ]
        text = '\n'.join(lines)
        axes[1].text(0.05, 0.95, f'{name} 风险指标\n\n'+text,
                     va='top', ha='left', fontsize=11,
                     bbox=dict(boxstyle='round', facecolor='white', alpha=0.8))
        fig.suptitle(f'{name} - 风险指标分析', fontsize=14)
        plt.tight_layout()
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True)
        
    def corr_matrix(self):
        """显示所有曲线收益相关性的热力图(看哪些策略雷同)"""
        if len(self.curves) < 2:
            messagebox.showerror('错误', '至少需要2条曲线'); return
        names = list(self.curves.keys())
        # 合并各曲线收益(按日期对齐)
        df = pd.DataFrame({n: self.curves[n]['pr'] for n in names})
        corr = df.corr()
        win = tk.Toplevel(self.root); win.title('策略收益相关性矩阵'); win.geometry('1100x800')
        fig, ax = plt.subplots(figsize=(10, 8))
        im = ax.imshow(corr.values, cmap='RdBu_r', vmin=-1, vmax=1)
        ax.set_xticks(range(len(names))); ax.set_xticklabels(names, rotation=45, ha='right', fontsize=9)
        ax.set_yticks(range(len(names))); ax.set_yticklabels(names, fontsize=9)
        # 填相关系数
        for i in range(len(names)):
            for j in range(len(names)):
                ax.text(j, i, f'{corr.values[i,j]:.2f}', ha='center', va='center', fontsize=8,
                        color='black')
        ax.set_title('各策略收益相关性矩阵', fontsize=14)
        fig.colorbar(im, ax=ax, label='相关系数')
        plt.tight_layout()
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True)



    def radar_chart(self):
        """多条曲线在5个整体指标上的雷达图对比（含正负值正确归一化，不断边不塌陷）"""
        if len(self.curves) < 2:
            messagebox.showerror('错误', '至少需要2条曲线'); return
        names = list(self.curves.keys())
        metrics = ['年化收益率','年化波动率','年化夏普率','最大回撤','卡玛比率']

        # 1) 计算各曲线指标
        vals = np.full((len(names), len(metrics)), np.nan)
        for i, n in enumerate(names):
            r = annual_report(self.curves[n]['pr'])
            for j, m in enumerate(metrics):
                vals[i, j] = r[m]

        # 2) 归一化: 统一转成 0~1 且"越大越好"(含负值处理)
        TINY = 1e-3                       # 负值/0 显示为极小值(边不断)
        norm = np.zeros_like(np.asarray(vals, float))
        for j, met in enumerate(metrics):
            col = np.asarray(vals[:, j], float)
            if np.isnan(col).any():
                col = np.nan_to_num(col, nan=0.0)
            if met in ('年化收益率','年化夏普率','卡玛比率'):
                # 越大越好 -> 除以最大值; 非正(0或负) -> 极小值
                pos = col[col > 0]
                if len(pos) == 0:
                    norm[:, j] = TINY
                else:
                    m = pos.max()
                    norm[:, j] = np.where(col > 0, col/m, TINY)
            elif met == '年化波动率':
                cv = np.maximum(np.abs(col), 1e-12)   # 波动越小越好
                norm[:, j] = cv.min() / cv
            elif met == '最大回撤':
                cv = np.maximum(np.abs(col), 1e-12)   # 回撤绝对值越小越好
                norm[:, j] = cv.min() / cv
            else:
                norm[:, j] = col

        # 3) 画雷达图
        win = tk.Toplevel(self.root); win.title('策略指标雷达图'); win.geometry('900x800')
        fig, ax = plt.subplots(figsize=(9, 9), subplot_kw=dict(polar=True))

        # 角度: 5个指标 → 6个点(闭合)
        angles = np.linspace(0, 2*np.pi, len(metrics), endpoint=False).tolist()
        angles += angles[:1]              # = 6 个

        for i, n in enumerate(names):
            vals_i = np.clip(norm[i], 0.0, 1.0)       # 截到[0,1]
            v = list(vals_i) + [vals_i[0]]             # 5个 → 6个(首尾闭合), 与angles对齐
            ax.plot(angles, v, 'o-', linewidth=2, label=n)
            ax.fill(angles, v, alpha=0.1)

        ax.set_xticks(angles[:-1]); ax.set_xticklabels(metrics, fontsize=11)
        ax.set_title('各策略整体指标雷达图\n(0=该项最差/负, 1=该项最优)', fontsize=13, pad=25)
        ax.legend(loc='upper right', bbox_to_anchor=(1.2, 1.1), fontsize=9)
        plt.tight_layout()
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True)



    def grid_search(self):
        """网格搜索: 对当前选中的配权方式, 试多个窗口/频率组合, 生成多条曲线"""
        sel = [a for a, v in self.asset_vars.items() if v.get()]
        meths = [k for k, v in self.meth_vars.items() if v.get()]
        if not sel:
            messagebox.showerror('错误', '请至少选一个资产'); return
        if not meths:
            messagebox.showerror('错误', '请至少选一种配权方式'); return

        # 弹出设置窗口: 输入窗口候选、频率候选
        win = tk.Toplevel(self.root); win.title('网格搜索 - 参数候选'); win.geometry('420x400')
        tk.Label(win, text='配权窗口候选(逗号分隔, 如 63,126,252):').pack(anchor='w', padx=10, pady=(10,2))
        e_looks = tk.Entry(win); e_looks.insert(0, '63,126,252'); e_looks.pack(fill=tk.X, padx=10)
        tk.Label(win, text='调仓频率候选(逗号分隔, 如 M,Q):').pack(anchor='w', padx=10, pady=2)
        e_freqs = tk.Entry(win); e_freqs.insert(0, 'M,Q'); e_freqs.pack(fill=tk.X, padx=10)
        tk.Label(win, text='杠杆倍数候选(逗号分隔, 如 1,1.3,1.5; 只输1表示不加):').pack(anchor='w', padx=10, pady=2)
        e_levers = tk.Entry(win); e_levers.insert(0, '1,1.3'); e_levers.pack(fill=tk.X, padx=10)
        h = [None]
        def ok():
            try:
                looks = [int(x) for x in e_looks.get().split(',') if x.strip()]
                freqs = [x.strip() for x in e_freqs.get().split(',') if x.strip()]
                levers = [float(x) for x in e_levers.get().split(',') if x.strip()]
            except:
                messagebox.showerror('错误', '输入格式错误'); return
            if not looks or not freqs or not levers:
                messagebox.showerror('错误', '候选不能为空'); return
            h[0] = (looks, freqs, levers); win.destroy()
        tk.Button(win, text='确定开始搜索', command=ok).pack(pady=10)
        self.root.wait_window(win)
        if h[0] is None: return
        looks, freqs, levers = h[0]
        try: start=self._cur_start()
        except ValueError as e: messagebox.showerror('错误',str(e)); return
        rf = self._cur_rf()

        added = 0
        for m in meths:
            budgets = None
            if m == 'rb':
                budgets = self.ask_budgets(sel)
                if budgets is None: return
            for look in looks:
                for freq in freqs:
                    for L in levers:
                        try:
                            pr, wdf = make_curve(self.prices, sel, m, budgets=budgets,
                                                 lookback=look, freq=freq, start=start)
                        except Exception as e:
                            continue
                        if L != 1.0:
                            pr = leverage_returns(pr, L, rf)
                        # 命名
                        tag = f'{",".join(sel)}|{m}'
                        if budgets is not None: tag = f'{",".join(sel)}|rb'
                        name = f'{tag}_w{look}_{freq}'
                        if abs(L-1.0) > 1e-9:
                            name += f'_L{L:g}'
                        name = self._new_name(name)
                        if name is None: continue
                        self.curves[name] = {'pr': pr, 'weights': wdf,
                                             'color': self.palette[len(self.curves)%20]}
                        added += 1
        messagebox.showinfo('网格搜索', f'已生成 {added} 条曲线')
        self._refresh_list()
        self.redraw(self._cur_roll())



    def heatmap_monthly(self):
        """显示选中曲线的 年份×月份 收益率热力图"""
        kb = self.listbox.selection()
        if not kb:
            messagebox.showerror('错误', '请先选择一条曲线'); return
        name = kb[0]
        pr = self.curves[name]['pr']
        # 月收益率
        mret = pr.resample('ME').apply(lambda x: (1+x).prod()-1)
        # 现金流 DataFrame: 行=月份, 列=年份
        df = mret.to_frame('r')
        df['年'] = df.index.year; df['月'] = df.index.month
        pivot = df.pivot_table(index='月', columns='年', values='r')
        win = tk.Toplevel(self.root); win.title(f'{name} - 月度收益率热力图'); win.geometry('1200x700')
        fig, ax = plt.subplots(figsize=(12, 7))
        # 转置: 行=年, 列=月
        im = ax.imshow(pivot.T.values, aspect='auto', cmap='RdYlGn', vmin=-0.1, vmax=0.1)
        ax.set_xticks(range(len(pivot.index))); ax.set_xticklabels(pivot.index)
        ax.set_yticks(range(len(pivot.columns))); ax.set_yticklabels(pivot.columns)
        # 填数值
        for i in range(len(pivot.columns)):
            for j in range(len(pivot.index)):
                v = pivot.iloc[j, i]
                if not pd.isna(v):
                    ax.text(j, i, f'{v*100:.1f}', ha='center', va='center', fontsize=8)
        ax.set_title(f'{name} - 月度收益率热力图(%)')
        fig.colorbar(im, ax=ax, label='月收益率')
        plt.tight_layout()
        figc = FigureCanvasTkAgg(fig, master=win)
        figc.get_tk_widget().pack(fill=tk.BOTH, expand=True)



    def eq_compare(self):
        """单资产对比: 第一页=净值, 第二页=日收益率 (带翻页按钮)"""
        kb = self.listbox.selection()
        if not kb:
            messagebox.showerror('错误', '请先选择一条组合曲线'); return
        name = kb[0]
        pr = self.curves[name]['pr']
        dat = self.curves[name]

        # 确定对比资产: 优先用该曲线的权重表列名
        wdf = dat.get('weights', pd.DataFrame())
        if wdf is not None and not wdf.empty:
            comp_assets = [c for c in wdf.columns if c in self.assets]
        else:
            comp_assets = self.assets

        comp_assets = [a for a in comp_assets if a in self.assets]
        if not comp_assets:
            messagebox.showerror('错误', '该曲线无可对比资产'); return

        # 组合日期对齐
        combo = self.prices[comp_assets].loc[pr.index]
        nav_combo = (1 + pr).cumprod()

        # ===== 窗口 =====
        win = tk.Toplevel(self.root); win.title(f'{name} - 单资产对比'); win.geometry('1150x700')

        # 顶部翻页按钮
        btnrow = tk.Frame(win); btnrow.pack(anchor='w', pady=5)
        self._eq_page = 0    # 0=净值, 1=日收益率
        def to_page(p):
            self._eq_page = p
            _render()
        tk.Button(btnrow, text='净值对比', command=lambda: to_page(0)).pack(side=tk.LEFT, padx=2)
        tk.Button(btnrow, text='日收益率对比', command=lambda: to_page(1)).pack(side=tk.LEFT, padx=2)

        # 画布容器(切换时销毁重建)
        plot_frame = tk.Frame(win); plot_frame.pack(fill=tk.BOTH, expand=True)
        self._eq_canvas = None

        def _render():
            nonlocal plot_frame
            # 清空旧画布
            if self._eq_canvas is not None:
                self._eq_canvas.get_tk_widget().destroy()
                plt.close(self._eq_canvas.figure)
                self._eq_canvas = None
            fig, ax = plt.subplots(figsize=(12, 6))

            if self._eq_page == 0:
                # 第一页: 净值对比
                ax.plot(nav_combo.index, nav_combo.values, label=f'组合:{name}', lw=2, color='black')
                for a in comp_assets:
                    s = combo[a].dropna()
                    if len(s) < 2: continue
                    nav = (1 + s.pct_change().fillna(0)).cumprod()
                    ax.plot(nav.index, nav.values, label=a, lw=1, alpha=0.6)
                ax.set_title(f'{name} vs 构成资产买入持有（净值）')
            else:
                # 第二页: 日收益率对比
                ax.plot(pr.index, pr.values, label=f'组合:{name}', lw=1.0, color='black', alpha=0.9)
                for a in comp_assets:
                    s = combo[a].dropna()
                    if len(s) < 2: continue
                    r = s.pct_change()
                    ax.plot(r.index, r.values, label=a, lw=0.5, alpha=0.6)
                ax.axhline(0, color='gray', lw=0.5)
                ax.set_title(f'{name} vs 构成资产 日收益率')

            ax.legend(fontsize=7, loc='upper left'); ax.grid(alpha=0.3)
            plt.tight_layout()
            self._eq_canvas = FigureCanvasTkAgg(fig, master=plot_frame)
            self._eq_canvas.get_tk_widget().pack(fill=tk.BOTH, expand=True)

        _render()

    def bind_mousewheel(self, widget, canvas):
        """递归绑定滚轮事件: 让 widget 及其所有子控件上滚轮都能滚动 canvas"""
        def on_wheel(e):
            canvas.yview_scroll(int(-1*(e.delta/120)), 'units')
        widget.bind('<MouseWheel>', on_wheel)
        for child in widget.winfo_children():
            self.bind_mousewheel(child, canvas)

    def compare_yearly(self):

        if not self.curves:
            messagebox.showerror(
                '错误',
                '请先添加曲线'
            )
            return

        yearly_dict = {}
        all_years = set()

        for name in self.curves:

            yr = yearly_report(
                self.curves[name]['pr']
            )

            if yr.empty:
                continue

            yearly_dict[name] = yr
            all_years.update(
                yr.index
            )

        if not yearly_dict:
            messagebox.showerror(
                '错误',
                '无年度数据'
            )
            return

        sorted_years = sorted(
            all_years
        )

        metrics = [
            '年化收益率',
            '年化波动率',
            '年化夏普率',
            '最大回撤',
            '卡玛比率'
        ]

        names = list(
            yearly_dict.keys()
        )

        # ========================================================
        # 窗口1：年度柱状图
        # ========================================================

        win1 = tk.Toplevel(
            self.root
        )

        win1.title(
            '对比所有曲线 - 年度柱状图'
        )

        win1.geometry(
            '1200x750'
        )

        c1 = tk.Canvas(
            win1,
            bg='white'
        )

        sb1 = tk.Scrollbar(
            win1,
            orient='vertical',
            command=c1.yview
        )

        c1.configure(
            yscrollcommand=sb1.set
        )

        c1.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )

        sb1.pack(
            side=tk.RIGHT,
            fill=tk.Y
        )

        fc1 = tk.Frame(c1)

        c1.create_window(
            (0, 0),
            window=fc1,
            anchor='nw'
        )

        fc1.bind(
            '<Configure>',
            lambda e:
            c1.configure(
                scrollregion=
                c1.bbox('all')
            )
        )

        for y in sorted_years:

            fig = plt.Figure(
                figsize=(14, 3.5),
                dpi=100
            )

            canvas = FigureCanvasTkAgg(
                fig,
                master=fc1
            )

            canvas.get_tk_widget().pack(
                fill=tk.BOTH,
                expand=True,
                pady=6,
                padx=6
            )

            axes = fig.subplots(
                1,
                5
            )

            for mj, met in enumerate(
                metrics
            ):

                vals = []

                for n in names:

                    if (
                        y in yearly_dict[n].index
                        and not pd.isna(
                            yearly_dict[n]
                            .loc[y, met]
                        )
                    ):

                        vals.append(
                            yearly_dict[n]
                            .loc[y, met]
                        )

                    else:

                        vals.append(0)

                axes[mj].bar(
                    names,
                    vals,
                    color=
                    '#4C9F70'
                    if met != '最大回撤'
                    else '#D9534F'
                )

                axes[mj].set_title(
                    f'{y} {met}',
                    fontsize=11
                )

                axes[mj].tick_params(
                    axis='x',
                    rotation=45,
                    labelsize=9
                )

                for lbl in axes[mj].get_xticklabels():
                    lbl.set_ha(
                        'right'
                    )

            fig.suptitle(
                f'{y}年 各指标对比',
                fontsize=14
            )

            fig.tight_layout()

        self.bind_mousewheel(
            fc1,
            c1
        )

        # ========================================================
        # 窗口2：年度指标表
        # ========================================================

        win2 = tk.Toplevel(
            self.root
        )

        win2.title(
            '对比所有曲线 - 年度指标表'
        )

        win2.geometry(
            '1100x700'
        )

        c2 = tk.Canvas(
            win2,
            bg='white'
        )

        sb2 = tk.Scrollbar(
            win2,
            orient='vertical',
            command=c2.yview
        )

        c2.configure(
            yscrollcommand=sb2.set
        )

        c2.pack(
            side=tk.LEFT,
            fill=tk.BOTH,
            expand=True
        )

        sb2.pack(
            side=tk.RIGHT,
            fill=tk.Y
        )

        fc2 = tk.Frame(
            c2
        )

        c2.create_window(
            (0, 0),
            window=fc2,
            anchor='nw'
        )

        fc2.bind(
            '<Configure>',
            lambda e:
            c2.configure(
                scrollregion=
                c2.bbox('all')
            )
        )

        rows_per_line = 3

        for i, y in enumerate(
            sorted_years
        ):

            if i % rows_per_line == 0:

                line_frame = tk.Frame(
                    fc2
                )

                line_frame.pack(
                    anchor='w',
                    pady=6
                )

            subf = tk.Frame(
                line_frame
            )

            subf.pack(
                side=tk.LEFT,
                padx=8
            )

            tk.Label(
                subf,
                text=f'{y}年',
                font=(
                    'Microsoft YaHei',
                    10,
                    'bold'
                )
            ).pack()

            tree = ttk.Treeview(
                subf,
                columns=
                ['资产'] + metrics,
                show='headings',
                height=len(names)+1
            )

            tree.heading(
                '资产',
                text='资产'
            )

            tree.column(
                '资产',
                width=130,
                anchor='w'
            )

            for m in metrics:

                tree.heading(
                    m,
                    text=m
                )

                tree.column(
                    m,
                    width=90,
                    anchor='center'
                )

            for n in names:

                vals = [n]

                for m in metrics:

                    if (
                        y in yearly_dict[n].index
                        and not pd.isna(
                            yearly_dict[n]
                            .loc[y, m]
                        )
                    ):

                        v = (
                            yearly_dict[n]
                            .loc[y, m]
                        )

                        if m in (
                            '年化收益率',
                            '年化波动率',
                            '最大回撤'
                        ):

                            vals.append(
                                f'{v*100:.2f}%'
                            )

                        else:

                            vals.append(
                                f'{v:.2f}'
                            )

                    else:

                        vals.append(
                            '—'
                        )

                tree.insert(
                    '',
                    'end',
                    values=vals
                )

            tree.pack()

        self.bind_mousewheel(
            fc2,
            c2
        )

if __name__=='__main__':
    PATH='资产指数数据.xlsx'   # ← 改成你的文件
    prices=load_prices(PATH)
    root=tk.Tk(); App(root,prices); root.mainloop()
