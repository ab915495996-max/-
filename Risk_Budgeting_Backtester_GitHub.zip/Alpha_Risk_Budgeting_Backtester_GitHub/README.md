# Dynamic Alpha Risk Budgeting Backtester

A Python-based interactive multi-strategy backtesting framework for multi-asset quantitative research.

## Project Overview

This project implements a research platform for testing dynamic asset allocation strategies, including:

- Multi-asset return processing and cleaning
- Risk budgeting portfolio construction
- Risk parity / inverse volatility / equal weight comparison
- Bridgewater-style growth-inflation regime framework
- Dynamic risk budget enhancement based on Sharpe/IR signals
- Interactive GUI for strategy comparison
- Performance analysis and export tools

## Main Features

### 1. Data Processing

The framework supports Excel-based price data and includes:

- Date parsing
- Missing value handling
- Return calculation
- Multi-asset alignment

### 2. Portfolio Optimization

Implemented methods include:

- Equal Weight
- Inverse Volatility Weighting
- Risk Parity
- Custom Risk Budget Optimization

The risk budgeting optimizer uses `scipy.optimize.minimize` with L-BFGS-B and SLSQP fallback.

### 3. Dynamic Risk Budgeting

The project converts asset-level IR/Sharpe signals into dynamic risk budgets through a monotonic Softplus mapping.

The workflow is:

```
Historical Returns
        |
        v
Expected Return / Volatility
        |
        v
Sharpe or IR Signal
        |
        v
Softplus Transformation
        |
        v
Dynamic Risk Budget
        |
        v
Portfolio Weights
```

### 4. Interactive Research GUI

The GUI provides:

- Asset selection
- Parameter configuration
- Strategy comparison
- NAV visualization
- Drawdown analysis
- Rolling Sharpe analysis
- Weight visualization
- Excel export

## Project Structure

```
.
├── README.md
├── requirements.txt
├── src
│   └── alpha_risk_budgeting_backtester.py
├── data
│   └── sample
├── results
└── .gitignore
```

## Installation

```bash
git clone <your-repository-url>
cd Alpha_Risk_Budgeting_Backtester_GitHub
pip install -r requirements.txt
```

## Running

```bash
python src/alpha_risk_budgeting_backtester.py
```

## Data Notice

Original market data files are not included because they may contain licensed financial data.
Users should provide their own compatible price dataset.

## Research Notes

This repository is for educational and research demonstration purposes. Backtest results should be evaluated with additional considerations including transaction costs, turnover, and out-of-sample validation.
